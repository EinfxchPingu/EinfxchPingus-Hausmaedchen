const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

const fs = require('fs');

const path = require('path');

const dataPath = path.join(__dirname, '..', 'config', 'data', 'casino.json');

module.exports = {

    data: new SlashCommandBuilder()

        .setName('bank')

        .setDescription('🏦〢Verwalte dein Bankkonto.')

        .addSubcommand(subcommand =>

            subcommand

                .setName('deposit')

                .setDescription('💰〢Zahle Coins in deine Bank ein.')

                .addStringOption(option =>

                    option.setName('amount')

                        .setDescription('🔢〢Der Betrag, den du einzahlen möchtest (Zahl oder "all").')

                        .setRequired(true))

        )

        .addSubcommand(subcommand =>

            subcommand

                .setName('withdraw')

                .setDescription('💸〢Hebe Coins von deiner Bank ab.')

                .addStringOption(option =>

                    option.setName('amount')

                        .setDescription('🔢〢Der Betrag, den du abheben möchtest (Zahl oder "all").')

                        .setRequired(true))

        ),

    async execute(interaction) {

        const userId = interaction.user.id;

        const input = interaction.options.getString('amount');

        let amount;

        

        let data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));

        if (!data[userId]) {

            data[userId] = { work: 0, slut: 0, crime: 0, balance: 0, bank: 0 };

        }

        

        if (input === "all") {

            if (interaction.options.getSubcommand() === 'deposit') {

                amount = data[userId].balance;

            } else if (interaction.options.getSubcommand() === 'withdraw') {

                amount = data[userId].bank;

            }

        } else {

            amount = parseInt(input, 10);

            if (isNaN(amount) || amount <= 0) {

                return interaction.reply({ content: `\`❌\`〢Bitte gib eine **gültige Zahl** oder "all" ein.`, ephemeral: true });

            }

        }

        if (interaction.options.getSubcommand() === 'deposit') {

            if (data[userId].balance < amount) {

                return interaction.reply({ content: `\`❌\`〢Du hast **nicht genügend** Coins auf deinem Konto. Dein **Guthaben**: **${data[userId].balance} Coins**`, ephemeral: true });

            }

            data[userId].balance -= amount;

            data[userId].bank += amount;

            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));

            const embed = new EmbedBuilder()

                .setColor("#5865f2")

                .setDescription(`### <:emoji_140:1313943323836416072> × EINZAHLUNG ERFOLGREICH

› Du hast \`${amount}\` Coins erfolgreich in **deine Bank** eingezahlt. Dein **neues Bankguthaben** beträgt \`${data[userId].bank}\` Coins.`);

            return interaction.reply({ embeds: [embed] });

        }

        if (interaction.options.getSubcommand() === 'withdraw') {

            if (data[userId].bank < amount) {

                return interaction.reply({ content: `\`❌\`〢Du hast **nicht genügend** Coins auf deinem **Bankkonto**. Dein **Bankguthaben**: **${data[userId].bank} Coins**`, ephemeral: true });

            }

            data[userId].bank -= amount;

            data[userId].balance += amount;

            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));

            const embed = new EmbedBuilder()

                .setColor("#5865f2")

                .setDescription(`### <:emoji_140:1313943323836416072> × ABHEBUNG ERFOLGREICH

› Du hast \`${amount}\` Coins **erfolgreich** von deiner **Bank** abgehoben. Dein **neues** Guthaben beträgt \`${data[userId].balance}\` Coins.`);

            return interaction.reply({ embeds: [embed] });

        }

    },

};