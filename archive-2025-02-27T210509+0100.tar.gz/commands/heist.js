const { SlashCommandBuilder } = require('@discordjs/builders');
const { EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

const teams = new Map();
const cooldownsPath = path.join(__dirname, '..', 'config', 'data', 'cooldowns.json');

function loadCooldowns() {
  let cooldowns = {};
  if (fs.existsSync(cooldownsPath)) {
    try {
      cooldowns = JSON.parse(fs.readFileSync(cooldownsPath, 'utf8'));
    } catch (err) {
      console.error('Fehler beim Laden der Cooldowns:', err);
    }
  }
  return cooldowns;
}

function saveCooldowns(data) {
  fs.writeFileSync(cooldownsPath, JSON.stringify(data, null, 2));
}

const COOLDOWN_TIME = 45 * 60 * 1000;

module.exports = {
  data: new SlashCommandBuilder()
    .setName('heist')
    .setDescription('💰〢Organisiere einen Heist und gewinne Geld!')
    .addSubcommand(subcommand =>
      subcommand.setName('create-team').setDescription('🤝〢Erstelle ein Team für den Heist'))
    .addSubcommand(subcommand =>
      subcommand
        .setName('join')
        .setDescription('✋〢Trete einem bestehenden Team bei')
        .addUserOption(option =>
          option.setName('ersteller').setDescription('Wähle den Team-Ersteller').setRequired(true)))
    .addSubcommand(subcommand =>
      subcommand
        .setName('strategie')
        .setDescription('🧠〢Lege eine Strategie für den Heist fest')
        .addStringOption(option =>
          option
            .setName('strategie')
            .setDescription('Wähle eine Strategie')
            .addChoices({ name: 'Aggressiv', value: 'aggressiv' }, { name: 'Schlau', value: 'schlau' })
            .setRequired(true)))
    .addSubcommand(subcommand =>
      subcommand.setName('start').setDescription('🚀〢Starte den Heist'))
    .addSubcommand(subcommand =>
      subcommand.setName('delete-team').setDescription('🗑️〢Lösche dein Team'))
    .addSubcommand(subcommand =>
      subcommand.setName('leave').setDescription('🚪〢Verlasse dein Team')),

  async execute(interaction) {
    const subcommand = interaction.options.getSubcommand();
    const userId = interaction.user.id;

    const cooldowns = loadCooldowns();

    if (subcommand === 'create-team') {
      if (teams.has(userId)) {
        return interaction.reply({ content: `\`❌\`〢Du hast bereits ein **Team** erstellt.`, ephemeral: true });
      }
      teams.set(userId, { members: [userId], strategy: null });
      return interaction.reply({
        content: `\`✅\`〢Du hast ein **Team** erstellt. **Mitglieder** müssen \`/heist join <dein name>\` verwenden, um **teilnehmen** zu **können**.`,
        ephemeral: true,
      });
    }

    if (subcommand === 'join') {
      const creator = interaction.options.getUser('ersteller');
      if (!teams.has(creator.id)) {
        return interaction.reply({
          content: `\`❌\`〢Das **Team** von <@${creator.id}> existiert nicht.`,
          ephemeral: true,
        });
      }
      const team = teams.get(creator.id);
      if (team.members.includes(userId)) {
        return interaction.reply({
          content: `\`❌\`〢Du **bist** bereits in diesem **Team**.`,
          ephemeral: true,
        });
      }
      team.members.push(userId);
      return interaction.reply({
        content: `\`✅\`〢Du bist dem **Team** von <@${creator.id}> beigetreten.`,
        ephemeral: true,
      });
    }

    if (subcommand === 'strategie') {
      const strategy = interaction.options.getString('strategie');
      if (!teams.has(userId)) {
        return interaction.reply({ content: `\`❌\`〢Du **hast** kein **Team** erstellt.`, ephemeral: true });
      }
      const team = teams.get(userId);
      team.strategy = strategy;
      return interaction.reply({
        content: `\`✅\`〢Du hast die **Strategie** auf \`${strategy}\` gesetzt.`,
        ephemeral: true,
      });
    }

    if (subcommand === 'start') {
      if (!teams.has(userId)) {
        return interaction.reply({ content: `\`❌\`〢Du **hast** kein **Team** erstellt.`, ephemeral: true });
      }

      const userCooldown = cooldowns[userId];
      if (userCooldown && Date.now() < userCooldown) {
        const cooldownEnd = Math.ceil((userCooldown - Date.now()) / 1000);
        return interaction.reply({
          content: `\`❌\`〢Du **kannst erst** in <t:${Math.floor((Date.now() + cooldownEnd * 1000) / 1000)}:R> einen weiteren **Heist** starten.`,
          ephemeral: true,
        });
      }

      const team = teams.get(userId);
      if (team.members.length < 2) {
        return interaction.reply({
          content: `\`❌\`〢Du **brauchst** mindestens **2 Mitglieder**, um einen **Heist** zu starten.`,
          ephemeral: true,
        });
      }

      if (!team.strategy) {
        return interaction.reply({
          content: `\`❌\`〢Du musst eine **Strategie** mit \`/heist strategie\` festlegen.`,
          ephemeral: true,
        });
      }

      const winChance = team.strategy === 'aggressiv' ? 40 : 55;
      const win = Math.random() * 100 < winChance;
      const reward = team.strategy === 'aggressiv'
        ? Math.floor(Math.random() * 10000 + 10000)
        : Math.floor(Math.random() * 5000 + 5000);

      teams.delete(userId);
      cooldowns[userId] = Date.now() + COOLDOWN_TIME;

      saveCooldowns(cooldowns);

      if (win) {
        const rewardPerMember = Math.floor(reward / team.members.length);
        const embed = new EmbedBuilder()
          .setDescription(`### <:emoji_139:1313936677810606191> × HEIST ERFOLGREICH!
› Ihr **habt** insgesammt **${reward}** stehlen **können**!
Jeder aus dem Team erhält: ${rewardPerMember}`)
          .setColor('#5865f2');
        return interaction.reply({ embeds: [embed] });
      } else {
        const embed = new EmbedBuilder()
          .setDescription(`### <:blurple_certifiedmoderator:1303388351822434335> × HEIST GESCHEITERT!
› Ihr **wurdet** entdeckt und habt **alles verloren**! 
In **45 Minuten** könnt ihr **einen neuen** Heist **starten**!`)
          .setColor('#5865f2');
        return interaction.reply({ embeds: [embed] });
      }
    }

    if (subcommand === 'delete-team') {
      if (!teams.has(userId)) {
        return interaction.reply({ content: `\`❌\`〢Du hast kein **Team** erstellt.`, ephemeral: true });
      }
      teams.delete(userId);
      return interaction.reply({ content: `\`✅\`〢Dein **Team** wurde gelöscht.`, ephemeral: true });
    }

    if (subcommand === 'leave') {
      for (const [creator, team] of teams.entries()) {
        if (team.members.includes(userId)) {
          if (creator === userId) {
            return interaction.reply({
              content: `\`❌\`〢Der **Team-Ersteller** kann das Team nicht **verlassen**. Nutze \`/heist delete-team\`.`,
              ephemeral: true,
            });
          }
          team.members = team.members.filter(member => member !== userId);
          return interaction.reply({
            content: `\`✅\`〢Du hast das **Team** verlassen.`,
            ephemeral: true,
          });
        }
      }
      return interaction.reply({ content: `\`❌\`〢Du **bist** in keinem **Team**.`, ephemeral: true });
    }
  },
};
