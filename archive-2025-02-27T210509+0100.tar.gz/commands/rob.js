const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

const fs = require('fs');

const path = require('path');

const dataPath = path.join(__dirname, '..', 'config', 'data', 'casino.json');

module.exports = {

    data: new SlashCommandBuilder()

        .setName('rob')

        .setDescription('🕵️〢Raube einen anderen Benutzer aus!')

        .addUserOption(option =>

            option.setName('target')

                .setDescription('👤〢Der Benutzer, den du ausrauben möchtest.')

                .setRequired(true)),

    async execute(interaction) {

        const userId = interaction.user.id;

        const targetUser = interaction.options.getUser('target');

        const targetUserId = targetUser.id;

        if (userId === targetUserId) {

            return interaction.reply({ content: `\`❌\`〢Du **kannst** dich **nicht** selbst **ausrauben**!`, ephemeral: true });

        }

        const cooldownTime = 30 * 60 * 1000; 

        const now = Date.now();

       

        let data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));

        if (!data[userId]) data[userId] = { work: 0, slut: 0, crime: 0, balance: 0, bank: 0, rob: 0 };

        if (!data[targetUserId]) data[targetUserId] = { work: 0, slut: 0, crime: 0, balance: 0, bank: 0, rob: 0 };

        

        if (now - data[userId].rob < cooldownTime) {

            const nextAvailableTime = data[userId].rob + cooldownTime;

            return interaction.reply({ content: `\`❌\`〢Ein **Cooldown** ist aktiv. Du **kannst** erst um <t:${Math.floor(nextAvailableTime / 1000)}:T> wieder **jemanden ausrauben**!`, ephemeral: true });

        }

       

        if (data[targetUserId].balance < 50) {

            return interaction.reply({ content: `\`❌\`〢Der **Benutzer** hat **nicht genügend** Coins, um **ausgeraubt** zu werden (**mindestens 50 Coins**).`, ephemeral: true });

        }

       

        const stealPercentage = Math.random() * 0.2 + 0.01;

        const stolenAmount = Math.floor(data[targetUserId].balance * stealPercentage);

       

        data[targetUserId].balance -= stolenAmount;

        data[userId].balance += stolenAmount;

        data[userId].rob = now; 

        fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));

        

        const embed = new EmbedBuilder()

            .setColor("#5865f2")

           

            .setDescription(`### <:emoji_139:1313936677810606191> × RAUB ERFOLGREICH
› Du hast **${stolenAmount} Coins** von <@${targetUser.id}> gestohlen!`)

          
        await interaction.reply({ embeds: [embed] });

    },

};