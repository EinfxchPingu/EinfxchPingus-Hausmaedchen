const { SlashCommandBuilder } = require('@discordjs/builders');
const { EmbedBuilder } = require('discord.js');
const path = require('path');
const fs = require('fs');

const STREAK_FILE = path.join(__dirname, '../config/data/streak.json');
const dataFilePath = path.join(__dirname, '..', 'config', 'data', 'level.json');
const moderationFilePath = path.join(__dirname, '..', 'config', 'data', 'moderation.json');
let data = require(dataFilePath);
let moderationData = require(moderationFilePath);

module.exports = {
  data: new SlashCommandBuilder()
    .setName('profile')
    .setDMPermission(false)
    .setDescription('📚〢Siehe dir das Profil von dir oder einer Person an')
    .addUserOption(option =>
      option
        .setName('user')
        .setDescription('👤〢Von wem das Profil?')
        .setRequired(false)
    ),
    
  async execute(interaction) {
    try {
      const user = interaction.options.getUser('user') || interaction.user;
      const userData = data.level.users.find(u => u.userid === user.id);
      const userLevel = userData ? userData.level : "*Hat kein Level*";

      const roleIds = {
        team: '1298918662199312385',
        partner: '1298777805865353389',
        leitung: '1298767485046095892'
      };
      
      const member = interaction.guild.members.cache.get(user.id);
      let status = "Mitglied dieses Servers";
      let emoji = "<:blurple_members:1303729183306027070>";

      if (member) {
        const userRoles = member.roles.cache;
        const isTeammitglied = userRoles.has(roleIds.team);
        const isPartner = userRoles.has(roleIds.partner);
        const isLeitung = userRoles.has(roleIds.leitung);

        if (isLeitung) {
          status = "Inhaber dieses Servers";
          emoji = "<:Krone:1303373280115167242>";
        } else if (isTeammitglied && isPartner) {
          status = "Teammitglied und Inhaber eines Partner-Servers";
          emoji = "<:Team:1303373355985932358> <:Partner:1303373291096113207>";
        } else if (isPartner) {
          status = "Inhaber eines Partner-Servers";
          emoji = "<:Partner:1303373291096113207>";
        } else if (isTeammitglied) {
          emoji = "<:Team:1303373355985932358>";
          status = "Teammitglied";
        }
      }

      let serverakte = "";
      let streak = "0";

      // Streaks aus Datei laden
      let streaks = {};
      if (fs.existsSync(STREAK_FILE)) {
        try {
          streaks = JSON.parse(fs.readFileSync(STREAK_FILE, 'utf8'));
        } catch (error) {
          console.error("Fehler beim Laden der Streak-Datei:", error);
        }
      }

      if (streaks[user.id]) {
        streak = streaks[user.id].streak || "0";
      }

      const warns = (moderationData.users && moderationData.users[user.id]?.warns) || [];
      
      if (warns.length > 0) {
        warns.forEach(userAction => {
          serverakte += `⚠️ - **Verwarnung** (**${new Date(userAction.date).toLocaleDateString()}**) \n` +
            `- Moderator: <@${userAction.moderator}>\n` +
            `- Grund: ${userAction.reason || 'Kein Grund angegeben'}\n\n`;
        });
      } else {
        serverakte = `*Keine Einträge in ${user.username}'s Server-Akte*`;
      }
      
      const embed = new EmbedBuilder()
        .setColor("#5865f2")
        .setDescription(`### <:5369blurpleinbox:1304086567509561487> × ${user.globalName || user.username}'s Server Profil
${emoji} › **Status**: ${status}
<:Sterne:1303373321244639242> › **Chat-Level**: ${userLevel}
<:3401_blurple_fire:1313883700253167668> › **Streak**: ${streak}

### <:Datei:1303373300554272789> - SERVER AKTE
${serverakte}`);

      await interaction.reply({ embeds: [embed] });
    } catch (error) {
      console.error(error);
      await interaction.reply({ content: '`❌`〢Es ist ein **Fehler** aufgetreten. Bitte versuche es **später erneut**.', ephemeral: true });
    }
  }
};
