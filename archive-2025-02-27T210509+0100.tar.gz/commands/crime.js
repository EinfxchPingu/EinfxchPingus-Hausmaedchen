const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

const dataPath = path.join(__dirname, '..', 'config', 'data', 'casino.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('crime')
        .setDescription('🕶️〢Begehe ein Verbrechen und riskiere alles!'),
    async execute(interaction) {
        const userId = interaction.user.id;
        const cooldownTime = 30 * 60 * 1000; 
        const now = Date.now();

        let data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
        if (!data[userId]) data[userId] = { work: 0, slut: 0, crime: 0, bank: 0 };

        if (now - data[userId].crime < cooldownTime) {
            const nextAvailableTime = data[userId].crime + cooldownTime;

            return interaction.reply({ content: `\`❌\`〢Ein **Cooldown** ist **Aktiv**. Du kannst erst um <t:${Math.floor(nextAvailableTime / 1000)}:T> wieder Geld verdienen`, ephemeral: true });
        }

        data[userId].crime = now;
        fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));

        const success = Math.random() < 0.6;
        if (success) {
            const reward = Math.floor(Math.random() * 500) + 100; 
            const embed = new EmbedBuilder()
                .setColor("#5865f2")
                .setDescription(`### <:3401_blurple_fire:1313883700253167668> × VERBRECHEN ERFOLGREICH
› Du hast ein Verbrechen begangen und **${reward} Coins** erbeutet!`);
            
            data[userId].balance += reward;
fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));

            
            return interaction.reply({ embeds: [embed] });
        } else {
            const loss = Math.floor(Math.random() * 300) + 50; 
            const embed = new EmbedBuilder()
                .setColor("#ed4245")
                .setDescription(`### <:blurple_ban:1303382706830315600> × VERBRECHEN FEHLGESCHLAGEN
› Die Polizei hat dich erwischt und du hast **${loss} Coins** verloren!`);

            return interaction.reply({ embeds: [embed] });
        }
    },
};
