const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

const dataPath = path.join(__dirname, '..', 'config', 'data', 'casino.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('slut')
        .setDescription('💋〢Versuche auf schmutzige Weise Geld zu verdienen!'),
    async execute(interaction) {
        const userId = interaction.user.id;
        const cooldownTime = 30 * 60 * 1000; 
        const now = Date.now();

        let data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
        if (!data[userId]) data[userId] = { work: 0, slut: 0, crime: 0, bank: 0 };

        if (now - data[userId].slut < cooldownTime) {
            const nextAvailableTime = data[userId].slut + cooldownTime;

            return interaction.reply({ content: `\`❌\`〢Ein **Cooldown** ist **Aktiv**. Du kannst erst um <t:${Math.floor(nextAvailableTime / 1000)}:T> wieder Geld verdienen!`, ephemeral: true });
        }

        data[userId].slut = now;
        fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
const reward = Math.floor(Math.random() * 200) + 50; 
            const embed = new EmbedBuilder()
                .setColor("#5865f2")
                .setDescription(`### <:Sterne:1303373321244639242> × ARBEIT ABGESCHLOSSEN
› Du hast dich durchgesetzt und **${reward} Coins** verdient!`);
        data[userId].balance += reward;
fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));

            
            return interaction.reply({ embeds: [embed] });
       
    },
};
