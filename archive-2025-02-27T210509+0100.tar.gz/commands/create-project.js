const { SlashCommandBuilder } = require('@discordjs/builders');
const { EmbedBuilder, ChannelType } = require('discord.js');
const path = require("path");
const projectPath = path.join(__dirname, '..', 'config', 'data', 'projects.json');
let data = require(projectPath);
const fs = require('fs');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('create-project')
        .setDMPermission(false)
        .setDescription('🎨〢Teile dein Projekt mit der Community')
        .addStringOption(option => 
            option.setName('titel')
                .setDescription('📚〢Der Titel deines Projekts')
                .setRequired(true)
        )
        .addStringOption(option => 
            option.setName('beschreibung')
                .setDescription('📋〢Die Beschreibung deines Projekts')
                .setRequired(true)
        )
        .addStringOption(option => 
            option.setName('links')
                .setDescription('🔗〢Zusätzliche Links zu deinem Projekt')
                .setRequired(true)
        )
        .addStringOption(option => 
            option.setName('tag')
                .setDescription('#️⃣〢Der Tag deines Projekts')
                .setRequired(true)
                .addChoices(
                    { name: '🤖 - Discord-Bot', value: 'discord-bot' },
                    { name: '🌐 - Webseite / Web-App', value: 'web' },
                    { name: '🎮 - Spiel', value: 'game' },
                    { name: '💻 - Software / App', value: 'software' },
                    { name: '📖 - Sonstiges', value: 'sonstiges' }
                )
        ),
    async execute(interaction) {
        const titel = interaction.options.getString('titel');
        const beschreibung = interaction.options.getString('beschreibung');
        const tag = interaction.options.getString('tag');
        const links = interaction.options.getString('links')
        const choice = interaction.options.getString('tag');
        let tagg = "";

        if (choice === 'discord-bot') {
            tagg = "1303720221764354048";
        }
        if (choice === 'web') {
            tagg = "1303720278148251779";
        }
        if (choice === 'game') {
            tagg = "1303720392875180042";
        }
        if (choice === 'software') {
            tagg = "1303744755787890770";
        }
        if (choice === 'sonstiges') {
            tagg = "1303720510806298655";
        }

        const userId = interaction.user.id;

        if (!data.users) {
            data.users = {};
        }
        
        if (data.users[userId]) {
            return interaction.reply({
            content: `\`❌\`〢Du **hast** bereits **ein Projekt** geteilt!`,
            ephemeral: true
        });
        } else if (!data.users[userId]) {
            data.users[userId] = { projects: [] }; 
            
        }


        const forumChannel = await interaction.guild.channels.fetch("1302556550099107880");

        if (forumChannel && forumChannel.type === ChannelType.GuildForum) {
            const embed = new EmbedBuilder()
                .setColor("#5865f2")
                .setDescription(`### <:Sterne:1303373321244639242> × NEUES PROJEKT
› <@${interaction.user.id}> hat sein **Projekt** hier mit euch **geteilt**. **Schaut** es euch doch gerne **mal an** und **bewertet** es!

### <:Datei:1303373300554272789> - BESCHREIBUNG DES PROJEKTES
› ${beschreibung}

### <:Link:1303373340920119376> - ZUSÄTZLICHE LINKS
› ${links}`);
      
            const post = await forumChannel.threads.create({
                name: titel,
                message: { embeds: [embed] },
                appliedTags: [tagg], 
            });
            const projectData = {
                project: true,
                postId: post.id
            };
            
            data.users[userId].projects.push(projectData);
            fs.writeFileSync(projectPath, JSON.stringify(data, null, 2));
        
        await interaction.reply({
            content: `\`✅\`〢Dein **Projekt** wurde erfolgreich **geteilt**! <#1302556550099107880>`,
            ephemeral: true
        });
    }
    },
};
