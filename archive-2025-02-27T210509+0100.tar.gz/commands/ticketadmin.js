const { SlashCommandBuilder } = require('@discordjs/builders');
const path = require('path');
const fs = require('fs');
const { ButtonBuilder, ButtonStyle, EmbedBuilder, ActionRowBuilder } = require('discord.js');

const dataFilePath = path.join(__dirname, '../config/data/ticket.json');
let data = require(dataFilePath);
const logChannelId = '1298922351320236032';

function formatDateInBerlinTimezone(date) {
  const berlinTimezone = 'Europe/Berlin';
  return new Date(date).toLocaleString('de-DE', { timeZone: berlinTimezone });
}

function extractDateFromFilename(filename) {
  const [timestamp] = filename.split('-');
  return new Date(timestamp).toLocaleDateString('de-DE', { timeZone: 'Europe/Berlin' });
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ticketadmin')
    .setDescription('🎫〢Ticket-Verwaltungsbefehle')
    .setDMPermission(false)
    .addSubcommand(subcommand =>
      subcommand
        .setName('closerequest')
        .setDescription('🔒〢Fordere die Schließung des Tickets an')
       )
    .addSubcommand(subcommand =>
      subcommand
        .setName('claim')
        .setDescription('👤〢Beanspruche ein Ticket')
    )
    .addSubcommand(subcommand =>
      subcommand
        .setName('unclaim')
        .setDescription('📩〢Gebe ein Ticket ab')
    ),
  async execute(interaction) {
    try {
      const subcommand = interaction.options.getSubcommand();
      const requiredRoles = ["1298918662199312385"];

      const hasPermission = requiredRoles.some(role => interaction.member.roles.cache.has(role));
      if (!hasPermission) {
        return interaction.reply({ content: '`❌`〢Dazu hast du **keine** Berechtigung', ephemeral: true });
      }

      const ticketData = data.tickets.find(u => u.ticketId === interaction.channelId);
      if (!ticketData && subcommand !== 'panelstatus' && subcommand !== 'history') {
        return interaction.reply({ content: '`❌`〢Dieser **Befehl** kann nur in einem **Ticket** ausgeführt werden.', ephemeral: true });
      }

      if (subcommand === 'closerequest') {
        const requestEmbed = new EmbedBuilder()
          .setDescription(`### <:Ticket:1303373350730596452> × TICKET SCHLIEßUNG
› <@${interaction.user.id}> hat das **Schließen** dieses Tickets **angefordert**. Bitte **akzeptiere** oder **verweigere** mit den untenstehenden **Buttons**.`)
          .setColor('#5865f2');

        const acceptButton = new ButtonBuilder()
          .setCustomId('accept')
          .setLabel(' - Akzeptieren')
          .setEmoji('1299810000365031552')
          .setStyle(ButtonStyle.Secondary);
        const verweigereButton = new ButtonBuilder()
          .setCustomId('verweigerung')
          .setLabel(' - Ablehnen')
          .setEmoji('1303373294094782484')
          .setStyle(ButtonStyle.Secondary);

        const requestRow = new ActionRowBuilder()
          .addComponents(acceptButton, verweigereButton);

        await interaction.reply({ content: `<@${ticketData.userid}>`, embeds: [requestEmbed], components: [requestRow] });
      } else if (subcommand === 'claim') {
        if (ticketData.claimed) {
          return interaction.reply({ content: '`❌`〢Dieses Ticket wurde bereits beansprucht.', ephemeral: true });
        }
        const claimEmbed = new EmbedBuilder()
          .setDescription(`### <:4020_blurple_wave:1303716667704082462> × Dein Ticket wurde beansprucht!
› <@${interaction.user.id}> ist nun **hier** und wird dir bei deinem **Anliegen** helfen.`)
          .setColor('#5865f2');

        ticketData.claimed = true;

        await interaction.reply({ embeds: [claimEmbed] });
        fs.writeFileSync(dataFilePath, JSON.stringify(data, null, 2));
      } else if (subcommand === 'unclaim') {
        if (!ticketData.claimed) {
          return interaction.reply({ content: '`❌`〢Dieses **Ticket** wurde noch nicht **beansprucht**.', ephemeral: true });
        }
        const claimEmbed = new EmbedBuilder()
          .setDescription(`### <:Flugzeug:1303373336050667541> × Das Ticket wurde abgegeben!
› <@${interaction.user.id}> hat das Ticket **abgeben**, jemand anderes wird sich nun um dein **Anliegen** kümmern.`)
          .setColor('#5865f2');

        ticketData.claimed = false;

        await interaction.reply({ embeds: [claimEmbed] });
        fs.writeFileSync(dataFilePath, JSON.stringify(data, null, 2));
      } else {
        await interaction.reply({ content: '`❌`〢Unbekannter Befehl.', ephemeral: true });
      }
    } catch (error) {
      console.error(error);
      await interaction.reply({ content: '`❌`〢Es ist ein Fehler aufgetreten. Bitte versuche es später erneut.', ephemeral: true });
    }
  },
};
