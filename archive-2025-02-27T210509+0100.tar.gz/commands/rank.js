const { SlashCommandBuilder } = require('@discordjs/builders');

const { AttachmentBuilder, PermissionsBitField } = require('discord.js');

const { RankCardBuilder } = require('discord-card-canvas');

const fs = require('fs');

const path = require('path');

const dataFilePath = path.join(__dirname, '..', 'config', 'data', 'level.json');

let data = require(dataFilePath);

module.exports = {

  data: new SlashCommandBuilder()

    .setName('rank')

    .setDMPermission(false)

    .setDescription('⭐〢Siehe dir deine Levelkarte oder die von anderen an')

    .addUserOption(option => option.setName('user').setDescription('👤〢Von wem die Levelkarte?').setRequired(false)),

  

  async execute(interaction) {

    try {

      const user = interaction.options.getUser('user') || interaction.user;

      const userData = data.level.users.find(u => u.userid === user.id);

      if (!userData) {

        return interaction.reply({ content: '`❌`〢Der **Benutzer** hat noch **keine** Levelkarte.', ephemeral: true });

      }
       

      const requiredXP = Math.ceil(100 * Math.pow(1.18, userData.level - 1));

      const currentXP = userData.xp;

      const sortedUsers = data.level.users.sort((a, b) => 
      b.level === a.level ? b.xp - a.xp : b.level - a.level
    );

    const userRank = sortedUsers.findIndex(u => u.userid === user.id) + 1;
        
        let currentuserrank = "";
        
        if (userRank === 1) {
            currentuserrank = { font: 'Inter', size: 60, weight: '600', color: '#FFD700' };
        } else if (userRank === 2) {
            currentuserrank = { font: 'Inter', size: 60, weight: '600', color: '#C0C0C0' };
        } else if (userRank === 3) {
            currentuserrank = { font: 'Inter', size: 60, weight: '600', color: '#CD7F32' };
        } else {
            currentuserrank = { font: 'Inter', size: 60, weight: '600', color: '#FFFFFF' };
        }

      const canvasRank = await new RankCardBuilder({

        currentLvl: userData.level,

        currentXP: currentXP,

        requiredXP: requiredXP,

        backgroundColor: { background: '#212831', bubbles: '#606afc' },

		avatarImgURL: user.displayAvatarURL({ extension: 'png', size: 256 }),

        nicknameText: { content: user.globalName || user.username, font: 'Poppins', color: '#FFFFFF' },

        userStatus: interaction.member.presence?.status || 'online',

        currentRank: userRank,

        requiredXPColor: '#FFFFFF',

  currentXPColor: '#FFFFFF',

  avatarBackgroundColor: '#00000000',

  colorTextDefault: '#FFFFFF',

  progressBarColor: '#606afc',

  lvlNumFormat: { font: 'Inter', size: 60, weight: '600', color: '#FFFFFF' },

  rankNumFormat: currentuserrank,

      }).build();

      const attachment = new AttachmentBuilder(canvasRank.toBuffer(), { name: 'rank.png' });

      
return interaction.reply({ files: [attachment] });

    } catch (error) {

      console.error(error);

      await interaction.reply({ content: '`❌`〢Es ist ein **Fehler** aufgetreten. Bitte versuche es **später erneut**.', ephemeral: true });

    }

  }

};