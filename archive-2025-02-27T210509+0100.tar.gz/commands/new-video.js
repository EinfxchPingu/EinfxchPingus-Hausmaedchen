const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('new-video')
        .setDescription('🎥〢Veröffentliche ein neues Video!')
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
        .addStringOption(option =>
            option.setName('link')
                .setDescription('🔗〢Der Youtube-Link')
                .setRequired(true)),

    async execute(interaction) {
        const link = interaction.options.getString('link');
        const targetChannelId = '1299121050310807583';

        
        
        const targetChannel = await interaction.client.channels.fetch(targetChannelId);
        if (!targetChannel || !targetChannel.isTextBased()) {
            return interaction.reply({ content: 'Fehler: Zielkanal nicht gefunden oder nicht gültig!', ephemeral: true });
        }

        const message = await targetChannel.send({ content:`@everyone
### <:cam:1299810456382214217> × NEUES VIDEO HOCHGELADEN
› <@956302585273405450> hat ein **neues Video** hochgeladen!
${link}`});

        await interaction.reply({ content: '`✅`〢Dein Video wurde veröffentlicht!', ephemeral: true });
    },
};
