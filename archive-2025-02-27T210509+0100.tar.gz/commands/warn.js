const { SlashCommandBuilder } = require('@discordjs/builders');
const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const path = require('path');
const fs = require('fs');

const dataFilePath = path.join(__dirname, '..', 'config', 'data', 'moderation.json');
let data = require(dataFilePath);

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warn')
    .setDescription('❗〢Verwarnt ein Mitglied.')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .setDMPermission(false)
    .addUserOption(option => option.setName('user').setDescription('👤〢Das Mitglied, das du verwarnen möchtest').setRequired(true))
    .addStringOption(option => option.setName('grund').setDescription('📚〢Grund für den Warn').setRequired(false)),
    
  async execute(interaction) {
    const member = interaction.options.getUser('user');
    const reason = interaction.options.getString('grund') || 'Kein Grund angegeben';
    const userId = member.id;

    if (!data.users) {
      data.users = {};
    }

    if (!data.users[userId]) {
      data.users[userId] = { warns: [] };
    }

    const warnData = {
      moderator: interaction.user.id,
      reason: reason,
      date: new Date().toISOString(),
    };

    try {
      const user = await interaction.client.users.fetch(member.id); 

      const embed = new EmbedBuilder()
        .setColor("#5865f2")
        .setDescription(`### <:Team:1303373355985932358> × DU WURDEST VERWARNT
            › **Du wurdest verwarnt**! **Achte** auf dein **Verhalten** und auf das **Einhalten** der Community-Richtlinien!
            
            ### <:Datei:1303373300554272789> - DETAILS
            - Moderator: <@${interaction.user.id}>
            - Grund: \`${reason}\``);

      await user.send({ embeds: [embed] });
    } catch (error) {
      console.error(`Konnte keine DM an ${member.tag} senden. ${error}`);
    }

    try {
      data.users[userId].warns.push(warnData);
      fs.writeFileSync(dataFilePath, JSON.stringify(data, null, 2));
    } catch (error) {
      console.error(`Fehler beim Schreiben in die Datei: ${error}`);
      await interaction.reply({ content: '`❌`〢Es ist ein **Fehler** beim Speichern aufgetreten.', ephemeral: true });
      return; 
    }

    await interaction.reply({ content: `\`⚠️\`〢<@${member.id}> wurde verwarnt. Grund: **${reason}**`, ephemeral: true });
  }
};
