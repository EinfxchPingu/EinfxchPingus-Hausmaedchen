const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

const dataFilePath = path.join(__dirname, '../config/data/gw.json');
let data = require(dataFilePath);

module.exports = {
  data: new SlashCommandBuilder()
    .setName('gw')
    .setDescription('Verwalte Gewinnspiele')
    .setDMPermission(false)
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand(subcommand =>
      subcommand
        .setName('reroll')
        .setDescription('👤〢Wähle einen neuen Gewinner eines Gewinnspiels aus')
        .addStringOption(option =>
          option.setName('messageid')
            .setDescription('🆔〢Die Nachrichten-ID des Gewinnspiels')
            .setRequired(true)))
    .addSubcommand(subcommand =>
      subcommand
        .setName('start')
        .setDescription('🎉〢Starte ein neues Gewinnspiel')
        .addChannelOption(option =>
          option.setName('channel')
            .setDescription('🧭〢Der Kanal worin das Gewinnspiel gestartet wird')
            .setRequired(true))
        .addIntegerOption(option =>
          option.setName('winners')
            .setDescription('👑〢Die Anzahl an Gewinnern')
            .setRequired(true))
        .addStringOption(option =>
          option.setName('prize')
            .setDescription('🎁〢Der Preis des Gewinnspiels')
            .setRequired(true))
        .addIntegerOption(option =>
          option.setName('duration')
            .setDescription('⏲️〢Die Dauer (in Minuten)')
            .setRequired(true))),
  
  async execute(interaction) {
    const subcommand = interaction.options.getSubcommand();

    if (subcommand === 'start') {
      const channel = interaction.options.getChannel('channel');
      const winnerCount = interaction.options.getInteger('winners');
      const prize = interaction.options.getString('prize');
      const duration = interaction.options.getInteger('duration') * 60 * 1000;
      const endTime = Date.now() + duration;

      if (!channel.isTextBased()) {
        return interaction.reply({ content: '`❌`〢Der **ausgewählte Kanal** ist kein **Text-Kanal**', ephemeral: true });
      }

      const message = await channel.send({
        embeds: [new EmbedBuilder()
          .setDescription(`### <:Geschenk:1303373310528192534> × NEUES GEWINNSPIEL
› Preis: **${prize}**

### <:Datei:1303373300554272789> - DETAILS 
- Teilnehmer: **0**
- Gewinner: **${winnerCount}**
- Endet: <t:${Math.floor(endTime / 1000)}:R> (<t:${Math.floor(endTime / 1000)}:f>)
- Erstellt von: <@${interaction.user.id}>

› Klicke unten auf die Schaltfläche, um am Gewinnspiel teilzunehmen. Ein weiterer Klick, um deine Teilnahme zurückzuziehen`)
          .setColor('#5865f2')],
        components: [new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId(`join_${Date.now()}`)
            .setLabel(' - Teilnehmen')
            .setEmoji('1303373310528192534')
            .setStyle(ButtonStyle.Secondary)
        )]
      });

      data.giveaways.push({
        id: Date.now().toString(),
        channelId: channel.id,
        messageId: message.id,
        winners: winnerCount,
        prize: prize,
        endTime: endTime,
        participants: [],
        creator: interaction.user.id,
        startTime: Date.now(),
      });

      fs.writeFileSync(dataFilePath, JSON.stringify(data, null, 2));
      await interaction.reply({ content: `\`🎉\`〢Das **Gewinnspiel** für den Preis **${prize}**, hat begonnen.`, ephemeral: true });

    } else if (subcommand === 'reroll') {
      const messageId = interaction.options.getString('messageid');
      const giveaway = data.history.find(gw => gw.messageId === messageId); 

      if (!giveaway) {
        return interaction.reply({ content: '`❌`〢Kein **Gewinnspiel** mit der angegebenen **Nachrichten-ID** gefunden.', ephemeral: true });
      }

      if (giveaway.participants.length === 0) {
        return interaction.reply({ content: '`❌`〢Es wurden **keine Teilnehmer** für dieses **Gewinnspiel** gefunden.', ephemeral: true });
      }

      const newWinners = [];
      for (let i = 0; i < giveaway.winners; i++) {
        if (giveaway.participants.length === 0) break;
        const randomIndex = Math.floor(Math.random() * giveaway.participants.length);
        const winner = giveaway.participants.splice(randomIndex, 1)[0];
        newWinners.push(winner);
      }

      const winnersMention = newWinners.map(winnerId => `<@${winnerId}>`).join(', '); 

      const winnerEmbed = new EmbedBuilder()
        .setTitle('`🎁`〢Herzlichen Glückwunsch')
        .setDescription(`${winnersMention}, du hast **${giveaway.prize}** gewonnen!`)
        .setColor('#5865f2');

      const rerollMessage = await interaction.reply({
        embeds: [winnerEmbed],
        ephemeral: false
      });

      data.history.push({
        messageId: messageId,
        winners: newWinners,
        prize: giveaway.prize,
        rerollTime: Date.now(),
      });

      fs.writeFileSync(dataFilePath, JSON.stringify(data, null, 2));
    }
  }
};
