const { SlashCommandBuilder } = require('@discordjs/builders');
const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('add-partner')
        .setDMPermission(false)
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
        .setDescription('🤝〢Füge einen Benutzer als Partner hinzu')
        .addUserOption(option => 
            option.setName('user')
                .setDescription('👤〢Der Benutzer, der als Partner hinzugefügt werden soll')
                .setRequired(true)
        ),
    async execute(interaction) {
        const targetUser = interaction.options.getUser('user');
        const guildMember = await interaction.guild.members.fetch(targetUser.id);

        const partnerRole = interaction.guild.roles.cache.find(role => role.id === '1298777805865353389');

        if (guildMember.roles.cache.has(partnerRole.id)) {
            return interaction.reply({ content: `\`❌\`〢<@${targetUser.id}> ist bereits **Partner**`, ephemeral: true });
        }

        await guildMember.roles.add(partnerRole);

        await interaction.reply({ content: `\`✅\`〢<@${targetUser.id}> wurde erfolgreich als Partner hinzugefügt!`, ephemeral: true });
    },
};
