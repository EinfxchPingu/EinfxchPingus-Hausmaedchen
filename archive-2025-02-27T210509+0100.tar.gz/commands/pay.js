const { SlashCommandBuilder } = require('@discordjs/builders');
const fs = require('fs');
const path = require('path');

const dataPath = path.join(__dirname, '..', 'config', 'data', 'casino.json');

function loadAccountData() {
  let accountData = {};
  if (fs.existsSync(dataPath)) {
    try {
      accountData = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
    } catch (err) {
      console.error('Fehler beim Laden der Kontodaten:', err);
      accountData = {};
    }
  }
  return accountData;
}

function saveAccountData(data) {
  fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('pay')
    .setDescription('💵〢Überweise Bargeld an einen anderen Nutzer.')
    .addUserOption(option =>
      option
        .setName('empfänger')
        .setDescription('👤〢Wähle den Empfänger der Überweisung.')
        .setRequired(true)
    )
    .addIntegerOption(option =>
      option
        .setName('betrag')
        .setDescription('💰〢Der Betrag, den du überweisen möchtest.')
        .setMinValue(1)
        .setRequired(true)
    ),

  async execute(interaction) {
    const accountData = loadAccountData();

    const senderId = interaction.user.id;
    const recipient = interaction.options.getUser('empfänger');
    const amount = interaction.options.getInteger('betrag');

    if (!recipient) {
      return interaction.reply({
        content: `\`❌\`〢Ungültiger **Empfänger**.`,
        ephemeral: true,
      });
    }

    const recipientId = recipient.id;

    if (!accountData[senderId]) {
      accountData[senderId] = { balance: 0, bank: 0 };
    }
    if (!accountData[recipientId]) {
      accountData[recipientId] = { balance: 0, bank: 0 };
    }

    if (accountData[senderId].balance < amount) {
      return interaction.reply({
        content: `\`❌\`〢Du hast **nicht genug** Bargeld (\`${accountData[senderId].balance}\`🪙), um diesen **Betrag** zu überweisen.`,
        ephemeral: true,
      });
    }

    accountData[senderId].balance -= amount;
    accountData[recipientId].balance += amount;

    saveAccountData(accountData);

    return interaction.reply({
      content: `\`✅\`〢Du hast \`${amount}\`🪙 an <@${recipientId}> überwiesen. Dein neuer **Kontostand**: \`${accountData[senderId].balance}\`🪙.`,
      ephemeral: true,
    });
  },
};
