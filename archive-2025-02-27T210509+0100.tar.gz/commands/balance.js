const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

const dataPath = path.join(__dirname, '..', 'config', 'data', 'casino.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('balance')
        .setDescription('💰〢Zeigt dein aktuelles Guthaben an oder das Guthaben eines anderen Benutzers!')
        .addUserOption(option => 
            option.setName('user')
                .setDescription('👤〢Der Benutzer, dessen Guthaben du sehen möchtest.')),
    async execute(interaction) {
        const userId = interaction.user.id;

        const targetUser = interaction.options.getUser('user') || interaction.user;
        const targetUserId = targetUser.id;

        let data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
        if (!data[targetUserId]) {
            data[targetUserId] = { work: 0, slut: 0, crime: 0, balance: 0, bank: 0 };
        }

        const balance = data[targetUserId].balance;
        
        const bank = data[targetUserId].bank;

        const embed = new EmbedBuilder()
            .setColor("#5865f2")
            .setDescription(`### <:Sterne:1303373321244639242> × GUTHABEN VON ${targetUser.globalName || targetUser.username}
› <@${targetUser.id}> hat \`${balance}\` Coins Bar bei sich und \`${bank}\` Coins auf der Bank`);

        await interaction.reply({ embeds: [embed] });
    },
};
