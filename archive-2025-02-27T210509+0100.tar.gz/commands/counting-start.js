const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const fs = require('fs');
const path = require('path');

const countingDataPath = path.join(__dirname, '../config', 'data', 'counting.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('counting-start')
        .setDMPermission(false)
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
        .setDescription('🔢〢Startet das Zählen und legt den Kanal fest')
        .addChannelOption(option => option.setName('channel').setDescription('📚〢Der Kanal für das Zählen').setRequired(true)),

    async execute(interaction) {
        const channel = interaction.options.getChannel('channel');
        
         const countingData = { channelId: channel.id, currentNumber: 0, lastUserId: null };
        fs.writeFileSync(countingDataPath, JSON.stringify(countingData));

        await channel.send(`### <:Rackete:1303373302818930738> × ZÄHLEN BIS UNENDLICH
› Die **nächste Zahl** ist **1**. **Achtung:** Jeder **darf nur** eine Zahl auf **einmal** schreiben– keine **doppelten** Nachrichten **hintereinander**!

Viel Spaß beim Zählen! 🎉`);
        await interaction.reply({ content: `\`🔢\`〢Das **Spiel** wurde in ${channel} gestartet!`, ephemeral: true });
    }
};

module.exports.getCountingData = () => ({
    countingChannelId,
    currentNumber,
    lastUserId
});
