const { SlashCommandBuilder } = require('@discordjs/builders');
const { EmbedBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits, StringSelectMenuBuilder, ChannelType, StringSelectMenuOptionBuilder, ActionRowBuilder, Events, ModalBuilder, TextInputBuilder, TextInputStyle, Embed } = require('discord.js');
const path = require('path');
const fs = require('fs');
const dataFilePath = path.join(__dirname, '../config/data/ticket.json');
let data = require(dataFilePath);

module.exports = {
  data: new SlashCommandBuilder()
    .setName('send-messages')
    .setDescription('🎫〢Sende Embed Servernachrichten')
    .setDMPermission(false)
		.setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
        .addStringOption(option =>
            option.setName('kategorie')
              .setDescription('📁〢Welche Embed-Nachrichten Kategorie')
              .setRequired(true)
              .addChoices(
                { name: '🎫 - Ticket erstellen', value: 'ticket' },
                { name: '🤖 - Bot Hosting', value: 'bot' },
                { name: '💞 - Boost Vorteile', value: 'boosts' },
                { name: '📚 - Regelwerk', value: 'regelwerk' },
                { name: '💻 - HostingNest Werbung', value: 'hostingnest' },
                { name: '🔥 - Forum Feedback', value: 'forum_feedback' },
                { name: '🔧 - Forum Coding-Hilfe', value: 'forum_coding' },
                { name: '🎨 - Forum Eure-Projekte', value: 'forum_projects' },
                { name: '👋 - Einführung', value: 'einführung' },
                { name: '📋 - Partnerschaft', value: 'partner' },
                { name: '🔗 - Rollen Vorteile', value: 'rollen_vorteile' },
                { name: '📚 - Einführung', value: 'einfuerung' },
                { name: '📫 - Code-teilen', value: 'code-sharing' },
                { name: '⛄ - Snowvember', value: 'snowvember' }
              )),
  async execute(interaction) {
    try {
      const choice = interaction.options.getString('kategorie');
    if (choice === "code-sharing") {
      const forumChannel = await interaction.guild.channels.fetch("1328699793832415304");

      if (forumChannel && forumChannel.type === ChannelType.GuildForum) {
          const embed = new EmbedBuilder()
              .setColor("#5865f2")
              .setDescription(`### <:Developer_Coding:1299810594387398788> × CODE-TEILEN 
› Willkommen bei der **Code-teilen**! Hier könnt ihr euren Code (**Achtung: keine großen Projekte**) mit der Community teilen!
Wichtig ist, dass ihr ihr euren eigenen Code **verstehen müssen könnt**. Das kann ein \`/ping\` command oder ein bestimmtes Event eines Minecraft Plugins sein, alles was anderen weiterhelfen könnte!

### <:Schilder:1303373314986741800> - RICHTLINIEN
› Es gilt wie gewohnt das <#1298766627046690930> , aber dennoch gibt es zusätzliche Regelungen:

\`§1\` - Der Code muss von euch geschrieben sein, geklautes zählt nicht und kann mit einer Verwarnung bestraft werden!

\`§2\` - Benutzt Kommentare (// oder #) um euren Code strukturierter und leserlicher zu machen.

\`§3\` - Vermeidet doppeltes! Gehe sicher, dass die Idee hinter deinem Code so noch nicht in diesem Forum existiert!`);
    
          const post = await forumChannel.threads.create({
              name: 'Willkommen beim Coding teilen! - Einführung & Richtlinien',
              message: { embeds: [embed] },
              appliedTags: ["1332429169660792842"], 
          });
          await interaction.reply({ content: '`✅`〢Die **Nachricht** wurde erfolgreich **gesendet**!', ephemeral: true });
    }
    }
     if (choice === "einfuerung") {
                 const embed = new EmbedBuilder()
        .setColor("#5865f2")
        .setImage("https://i.ibb.co/g4nVbnd/a-e1d98b482464528503894180c4fdaef4.gif")
        .setDescription(`### <:Navigator:1303373297119137853> × EINFÜHRUNG IN DEN SERVER
› **Hey!** Mein Name ist **EinfxchPingu** und du bist **wohl** auf meinen **Discord-Server gestolpert**. Wir sind ein **aktiver deutscher Community** Discord-Server mit dem **Server Thema** “Coding & Chill“. Außerdem **kannst** du hier **gratis deine Discord-Bots hosten**.

- Du **kannst** auch gerne meinen [**Youtube Kanal**](https://www.youtube.com/@EinfxchPingu) abchecken und dir **paar Tutorials** reinziehen!
- Hier **findest** du alle **Informationen** über die **meisten Ränge** auf unserem **Server** und dessen **Vorteile**, Anforderungen **oder** Aufgaben.

**Klicke** auf eine **Kategorie** im **Dropdown-Menü**, um zu **starten**!
Bei **Problemen** oder **Fragen**, melde **dich** beim <#1298951101223145472>.`);
const einführungselect = new StringSelectMenuBuilder()
.setCustomId('einführungselect')
.setPlaceholder('📚〢Informationen zu diesem Server')
.addOptions(
new StringSelectMenuOptionBuilder()
  .setLabel('Boost Vorteile')
  .setEmoji('1304087425131348008')
  .setDescription('Klicken mich an um diese Option auszuwählen')
  .setValue('vorteile_boost'),
  new StringSelectMenuOptionBuilder()
  .setLabel('Server Erfolge')
  .setEmoji('1303373321244639242')
  .setDescription('Klicken mich an um diese Option auszuwählen')
  .setValue('server_erfolge'),
  new StringSelectMenuOptionBuilder()
  .setLabel('Special Rollen')
  .setEmoji('1302714885104336896')
  .setDescription('Klicken mich an um diese Option auszuwählen')
  .setValue('server_spezialrollen'),
  new StringSelectMenuOptionBuilder()
  .setLabel('Level Rollen')
  .setEmoji('1303373321244639242')
  .setDescription('Klicken mich an um diese Option auszuwählen')
  .setValue('server_levelrollen'),
  new StringSelectMenuOptionBuilder()
  .setLabel('Mein Youtube-Kanal')
  .setEmoji('1299810456382214217')
  .setDescription('Klicken mich an um diese Option auszuwählen')
  .setValue('youtube_kanal'),
  new StringSelectMenuOptionBuilder()
  .setLabel('Interaktion abbrechen')
  .setEmoji('1303373294094782484')
  .setDescription('Klicken mich an um diese Interaktion abzubrechen')
  .setValue('cancel'),

);
const row = new ActionRowBuilder()
.addComponents(einführungselect);

await interaction.channel.send({embeds: [embed], components: [row]});
await interaction.reply({ content: '`✅`〢Die **Nachricht** wurde erfolgreich **gesendet**!', ephemeral: true });
     }
     if (choice === "rollen_vorteile") {
          const embed = new EmbedBuilder()
          .setColor("#5865f2")
          .setDescription(`### <:Schilder:1303373314986741800> × INVITE VORTEILE
› Wenn du andere Benutzer auf den Server einlädst, bekommst
du viele tolle Belohnungen von uns! Die Eingeladeten dürften keine alt-accs sein.

<@&1313126654356361298> 
- Alle Vorteile von Türsteher
- +1 zusätzliche Server Slots
- Kleiner Discord Bot von uns! (Ticketsystem + Level)
- +150MB RAM
- +600MB Speicher
- Eigenes Icon für die Rolle

<@&1313126657153961994> 
- Alle Vorteile von Schildträger
- Im Nächsten Video wirst du gegrüßt
- Eigene Rolle + Farbe
- +125MB RAM
- + 250MB Speicher

<@&1313126660173856790>
- +80MB RAM
- +250MB Speicher
- Zugriff auf <#1313468806034886698>

**WICHTIG**: Ihr müsst euren eigenen Invite-Link erstellen! *Wenn ihr unten auf den Button "Invite Belohnungen einfordern" klickt, öffnet sich ein Ticket.*`);
         
         const inviteButton = new ButtonBuilder()
.setCustomId('inviteButton')
.setLabel(' - Invite Belohnungen einfordern')
.setEmoji('1303373340920119376')
.setStyle(ButtonStyle.Secondary);

const inviteRow = new ActionRowBuilder()
.addComponents(inviteButton);
         
        
        await interaction.channel.send({ embeds: [embed], components: [inviteRow]});
await interaction.reply({ content: '`✅`〢Die **Nachricht** wurde erfolgreich **gesendet**!', ephemeral: true });
     }
      if (choice === "partner") {
        const embed = new EmbedBuilder()
          .setColor("#5865f2")
          .setDescription(`### <:Partner:1303373291096113207> × PARTNERSCHAFT VORRAUSSETZUNGEN

- Mindestens 100 Mitglieder (Ohne Bots)
- Aktive Community
- Server Fokus auf Coding & Chill
- Der Server verstößt nicht gegen die Nutzungsbedingungen von Discord
- **Wir erhalten einen eigenen Kanal**

### <:Sterne:1303373321244639242> - VORTEILE ALS PARTNER

- Weitere Gratis Bot Server Slots (Abhängig von der Mitglieder-Anzahl)
- <@&1298777805865353389>
- Eigener Kanal mit deiner Werbung *(Ab 250 Mitgliedern)*

<:Information:1303373343705010216> › **Wenn** du die **Vorraussetzungen** erfüllst, **kannst** du unten auf den **Button** "Für Partnerschaft bewerben" klicken.`);
const partnerButton = new ButtonBuilder()
.setCustomId('partnerschaft')
.setLabel(' - Für Partnerschaft bewerben')
.setEmoji('1303373291096113207')
.setStyle(ButtonStyle.Secondary);

const partnerRow = new ActionRowBuilder()
.addComponents(partnerButton);
        
        await interaction.channel.send({ embeds: [embed], components: [partnerRow]});
await interaction.reply({ content: '`✅`〢Die **Nachricht** wurde erfolgreich **gesendet**!', ephemeral: true });
      }
      if (choice === "einführung") {
        const embed = new EmbedBuilder()
        .setColor("#5865f2")
        .setDescription(`### <:Flugzeug:1303373336050667541> × **EINFÜHRUNG IN DEN SERVER**
› **Schön**, dass du **da bist**! In dem **Dropdown-Menü** unten findest du **verschiedene Kategorien**, die dir **helfen**, dich auf dem **Server** zurechtzufinden. **Wähle** einfach eine **Option** und erhalte **detaillierte Informationen**.

### <:Datei:1303373300554272789> × **VERFÜGBARE OPTIONEN**
- Alle Kanäle anzeigen
- Hosting Angebot
- Coding-Hilfe
- Eure Projekte
- Mein YouTube-Kanal
- Ticket Support
- Server Rollen/Erfolge
- Bewerbungsphase

<:Sterne:1303373321244639242> › Ich **wünsche** dir noch **viel Spaß** auf dem **Server**!`);
const einführungselect = new StringSelectMenuBuilder()
.setCustomId('einführungselect')
.setPlaceholder('📚〢Informationen zu diesem Server')
.addOptions(
new StringSelectMenuOptionBuilder()
  .setLabel('Alle Kanäle anzeigen')
  .setEmoji('1302715658794176594')
  .setDescription('Klicken mich an um diese Option auszuwählen')
  .setValue('optionen'),
  new StringSelectMenuOptionBuilder()
  .setLabel('Hosting Angebot')
  .setEmoji('1303373305973313658')
  .setDescription('Klicken mich an um diese Option auszuwählen')
  .setValue('hosting4free'),
  new StringSelectMenuOptionBuilder()
  .setLabel('Coding-Hilfe')
  .setEmoji('1299810594387398788')
  .setDescription('Klicken mich an um diese Option auszuwählen')
  .setValue('coding_hilfe'),
  new StringSelectMenuOptionBuilder()
  .setLabel('Eure Projekte')
  .setEmoji('1303729183306027070')
  .setDescription('Klicken mich an um diese Option auszuwählen')
  .setValue('eure_projekte'),
  new StringSelectMenuOptionBuilder()
  .setLabel('Mein Youtube-Kanal')
  .setEmoji('1299810456382214217')
  .setDescription('Klicken mich an um diese Option auszuwählen')
  .setValue('youtube_kanal'),
  new StringSelectMenuOptionBuilder()
  .setLabel('Ticket Support')
  .setEmoji('1303373350730596452')
  .setDescription('Klicken mich an um diese Option auszuwählen')
  .setValue('ticket_support'),
  new StringSelectMenuOptionBuilder()
  .setLabel('Server Rollen/Erfolge')
  .setEmoji('1303373321244639242')
  .setDescription('Klicken mich an um diese Option auszuwählen')
  .setValue('server_rollen'),
  new StringSelectMenuOptionBuilder()
  .setLabel('Bewerbungsphase')
  .setEmoji('1303373355985932358')
  .setDescription('Klicken mich an um diese Option auszuwählen')
  .setValue('bewerbung_schreiben'),
  new StringSelectMenuOptionBuilder()
  .setLabel('Keine Bot-DMs?')
  .setEmoji('1303373361291726968')
  .setDescription('Klicken mich an um diese Option auszuwählen')
  .setValue('keine_botdms'),
  new StringSelectMenuOptionBuilder()
  .setLabel('Interaktion abbrechen')
  .setEmoji('1303373294094782484')
  .setDescription('Klicken mich an um diese Interaktion abzubrechen')
  .setValue('cancel'),

);
const row = new ActionRowBuilder()
.addComponents(einführungselect);

await interaction.channel.send({embeds: [embed], components: [row]});
await interaction.reply({ content: '`✅`〢Die **Nachricht** wurde erfolgreich **gesendet**!', ephemeral: true });
      }
      if (choice === "snowvember") {
        const embed = new EmbedBuilder()
          .setColor("#5865f2")
          .setDescription(`### <:christmas_tree:1299810501504536707> × SNOWVEMBER
› **Endlich** ist es **Winter** und Weihnachten rückt näher. Für dieses **Jahr**, habe ich ein kleines **Event** geplant. Ich **hoffe** ihr habt **Spaß**!

### <:Diamant:1302714840019636327> - BELOHNUNGEN

- **Discord Nitro Basic** *(3 Verbleibend)* × **1500** <:Christmas_Candy_Cane:1300467228415623209> 
- **Einen Zusatz Server Slot** *(6 Verbleibend)* × **950** <:Christmas_Candy_Cane:1300467228415623209> 
- **<@&1298798182247174244>** *(Unendlich Verbleibend)* × **650** <:Christmas_Candy_Cane:1300467228415623209>
- **+85MB RAM** *(15 Verbleibend)* × **200** <:Christmas_Candy_Cane:1300467228415623209> 
- **+500MB Speicher** *(20 Verbleibend)* × **200** <:Christmas_Candy_Cane:1300467228415623209> 

### <:Datei:1303373300554272789> - EVENT DETAILS
› In diesem **Event**, könnt ihr euch <:Christmas_Candy_Cane:1300467228415623209> **Zuckerstangen** durchs schreiben von **Nachrichten** verdienen! oben seht ihr die **Belohnungen**, die ihr euch **kaufen** könnt, gelistet. Das **Event** geht vom **1 Dezember** bis zum **24 Dezember**.`);
const snowvemberselect = new StringSelectMenuBuilder()
.setCustomId('snowvemberselect')
.setPlaceholder('⛄〢Kaufe dir was im Shop..')
.addOptions(
  new StringSelectMenuOptionBuilder()
    .setLabel('+500MB Speicher (200)')
    .setEmoji('1304086566125441054')
    .setDescription('Klicken mich an um dieses Produkt zu kaufen')
    .setValue('speicher'),
    new StringSelectMenuOptionBuilder()
    .setLabel('+85 MB Ram (200)')
    .setEmoji('1304086568792883290')
    .setDescription('Klicken mich an um dieses Produkt zu kaufen')
    .setValue('ram'),
    new StringSelectMenuOptionBuilder()
    .setLabel('Snowvember Event Rolle (650)')
    .setEmoji('1303443528529088522')
    .setDescription('Klicken mich an um dieses Produkt zu kaufen')
    .setValue('event_rolle'),
    new StringSelectMenuOptionBuilder()
    .setLabel('Einen Zusatz Server Slot (950)')
    .setEmoji('1303373305973313658')
    .setDescription('Klicken mich an um dieses Produkt zu kaufen')
    .setValue('server_slot'),
    new StringSelectMenuOptionBuilder()
    .setLabel('Discord Nitro Basic (1500)')
    .setEmoji('1304087425131348008')
    .setDescription('Klicken mich an um dieses Produkt zu kaufen')
    .setValue('nitro'),
    new StringSelectMenuOptionBuilder()
    .setLabel('Interaktion abbrechen')
    .setEmoji('1303373294094782484')
    .setDescription('Klicken mich an um diese Interaktion abzubrechen')
    .setValue('cancel'),

);
const row = new ActionRowBuilder()
.addComponents(snowvemberselect);

await interaction.channel.send({embeds: [embed], components: [row]});
await interaction.reply({ content: '`✅`〢Die **Nachricht** wurde erfolgreich **gesendet**!', ephemeral: true });
      }
if (choice === 'forum_feedback') {
  const forumChannel = await interaction.guild.channels.fetch("1298944155149537301");

  if (forumChannel && forumChannel.type === ChannelType.GuildForum) {
      const embed = new EmbedBuilder()
          .setColor("#5865f2")
          .setDescription(`### <:Schilder:1303373314986741800> × FEEDBACK FORUM
› **Herzlich Willkommen** im **Feedback-Forum**. Hier könnt ihr uns **Verbesserungsvorschläge** geben oder unseren **Server bewerten** und eure **Meinung** äußern.

### <:Regelwerk:1303373332690899024> - POST RICHTLINIEN
\`§1\` - Bleibt freundlich und fair – Konstruktive Kritik ist super, aber denkt daran, freundlich zu bleiben.

\`§2\` - Gebt euer Feedback möglichst klar und auf den Punkt, damit wir euch besser verstehen.

\`§3\` - Wenn ihr etwas kritisiert, bringt am besten gleich Ideen zur Verbesserung mit.

\`§4\` - Spam und Off-Topic-Kommentare bringen uns nicht weiter, also lieber vermeiden.

\`§5\` - Achtet darauf, euer Feedback in der passenden Kategorie (oder hier Tags) zu posten, so findet es jeder schneller.

> Danke, dass ihr euch die Zeit nehmt, uns zu helfen, den Server zu verbessern!`);

      const post = await forumChannel.threads.create({
          name: 'Willkommen im Feedback Forum! - Einführung & Richtlinien',
          message: { embeds: [embed] },
          appliedTags: ["1299848980531904552"], 
      });
      await interaction.reply({ content: '`✅`〢Die **Nachricht** wurde erfolgreich **gesendet**!', ephemeral: true });
}
}
if (choice === 'forum_coding') {
  const forumChannel = await interaction.guild.channels.fetch("1298950388782731285");

  if (forumChannel && forumChannel.type === ChannelType.GuildForum) {
      const embed = new EmbedBuilder()
          .setColor("#5865f2")
          .setDescription(`### <:Team:1303373355985932358> × CODING-HILFE
› **Herzlich willkommen** bei der **Coding-Hilfe**! Wenn du bei deinem **Code** oder anderen technischen **Themen** Unterstützung brauchst, kannst du hier einen **Post** erstellen und wirst in der Regel **Hilfe** erhalten.

### <:Regelwerk:1303373332690899024> - RICHTLINIEN FÜR POSTS
\`§1\` - Dieser Bereich ist nicht dazu gedacht, dass andere für dich programmieren oder Aufgaben vollständig übernehmen. Stelle nur Fragen, wenn du bereits selbst Lösungsansätze ausprobiert hast und weiterkommst.

\`§2\` - Wir übernehmen keine Haftung für Schäden oder Fehlfunktionen, die durch hier geteilte Skripte oder Programme entstehen könnten.

\`§3\` - Um Unterstützung zu erhalten, solltest du Grundkenntnisse in Programmierung sowie in den Betriebssystemen Windows, Linux oder macOS mitbringen und eine grobe Vorstellung von deinem Vorhaben haben.

\`§4\` - Beschreibe dein Problem so genau wie möglich. Füge relevante Code-Snippets, Fehlermeldungen und verwendete Technologien hinzu, um schnelle und zielgerichtete Hilfe zu erhalten.

\`§5\` - Veröffentliche keine sensiblen Informationen wie Passwörter, API-Schlüssel oder personenbezogene Daten. Diese können missbraucht werden.

\`§6\` - Respektiere die Helfenden und sei geduldig. Die meisten Helfenden unterstützen in ihrer Freizeit, und Antworten können einige Zeit in Anspruch nehmen.

\`§7\` - Sobald dein Problem gelöst ist, markiere deinen Beitrag als „gelöst“, damit andere wissen, dass du keine Hilfe mehr benötigst.

\`§8\` - Poste dein Anliegen nur einmal und halte dich an den bestehenden Post, um Doppelungen zu vermeiden und die Übersichtlichkeit zu wahren.`);

      const post = await forumChannel.threads.create({
          name: 'Willkommen bei der Coding-Hilfe! - Einführung & Richtlinien',
          message: { embeds: [embed] },
          appliedTags: ["1299649094461165578"], 
      });
      await interaction.reply({ content: '`✅`〢Die **Nachricht** wurde erfolgreich **gesendet**!', ephemeral: true });
}
}
if (choice === 'forum_projects') {
  const forumChannel = await interaction.guild.channels.fetch("1302556550099107880");

  if (forumChannel && forumChannel.type === ChannelType.GuildForum) {
      const embed = new EmbedBuilder()
          .setColor("#5865f2")
          .setDescription(`### <:hastag:1302715658794176594> × EURE PROJEKTE - INFO
› **Herzlich Willkommen** im „Eure Projekte“-Channel! Hier kannst du **deine Projekte** mit anderen **teilen** und **Feedback** erhalten.

### <:Rackete:1303373302818930738> - WIE KANN ICH MEIN PROJEKT EINREICHEN?
› **Reiche** dein **Projekt** ein, indem du den **Command** \`/create-project\` von unserem <@1303418042415448076> Bot **nutzt**. Gib dabei einen **Titel** und eine **Beschreibung** zu deinem **Projekt** an – dein Beitrag wird dann **automatisch** in diesem **Forum** erstellt!

### <:Bot:1303373287962710062>  - WAS ZÄHLT ALS PROJEKT?
› Als **Projekt** zählt **alles**, was **Kreativität** zeigt, sei es **Kunst**, **Musik** oder eine **technische** Entwicklung. **Wichtig**: Poste nur **SFW (Safe for Work)** Inhalte; **Discord-Server** und andere **Communities** sind dabei **nicht gestattet**.`);

      const post = await forumChannel.threads.create({
          name: 'Willkommen bei euren Projekten! - Einführung & Richtlinien',
          message: { embeds: [embed] },
          appliedTags: ["1303439709112111275"], 
      });
      await interaction.reply({ content: '`✅`〢Die **Nachricht** wurde erfolgreich **gesendet**!', ephemeral: true });
}
}
if (choice === 'regelwerk') {
  const ticketEmbed = new EmbedBuilder()
  .setColor("#5865f2")
  .setDescription(`### <:Regelwerk:1303373332690899024> × UNSER SERVER-REGELWERK
› Durch das Betreten des Discord Servers, akzeptierst du automatisch unser Regelwerk.
› Es gelten standartmäßig die [ToS](https://discord.com/terms) sowie die [Guidelines](https://discord.com/guidelines) von Discord.

\`§1\`・**Verhalten**  
\`§1.1\` - Behandle alle respektvoll. Beleidigungen, Belästigungen und Diskriminierung sind untersagt.  
\`§1.2\` - Persönliche Konflikte bitte privat klären, nicht öffentlich. Vermeide unnötige Streitereien im Chat.  
\`§1.3\` - Absichtliches Stören von Gesprächen wird geahndet.  
\`§1.4\` - Vermeide störende Geräusche wie ins Mikrofon atmen oder lautes Kauen. Hintergrundgespräche, die nicht alle Mitglieder eines Channels betreffen, gehören nicht auf Discord. Stelle dich in solchen Fällen bitte stumm oder verlasse den Channel.  
\`§1.5\` - Sinnloses Wechseln zwischen Channels ("Channel-Hopping") ist verboten und kann im Extremfall zum Ausschluss führen.
\`§1.6\` - Das absichtliche Zerstören der <#1304091107050655825> Streak oder das Bearbeiten von Nachrichten, um andere Spieler zu täuschen, ist ab sofort nicht erlaubt. Solches Verhalten kann mit einem Ausschluss aus dem Spiel geahndet werden!

\`§2\`・**Inhalte**  
\`§2.1\` - Poste keine anstößigen, illegalen, pornografischen oder urheberrechtlich geschützten Inhalte.  
\`§2.2\` - Vermeide vulgäre, anstößige oder beleidigende Sprache.  
\`§2.3\` - Spam, Werbung, wiederholte Nachrichten oder Inhalte, die den Server überladen, sind nicht erlaubt.
\`§2.4\` - Das Abwerben von Spielern für andere Discord- oder anderes  ist nicht erlaubt und wird bestraft.

\`§3\`・**Sicherheit**  
\`§3.1\` - Teile keine persönlichen Informationen von dir oder anderen, wie Fotos, Adressen oder Kontaktinformationen.  
\`§3.2\` - Poste keine verdächtigen Links oder Dateien, die Malware enthalten könnten.  
\`§3.3\` - Schütze deine Konten mit starken Passwörtern und teile keine Zugangsdaten.  
\`§3.4\` - Das Mitschneiden von Gesprächen ist verboten, um eure Privatsphäre zu schützen.

\`§4\`・**Benutzername und Avatare**  
\`§4.1\` - Benutzernamen müssen mit einer normalen Deutschen/Amerikanischen Tastatur schreibbar sein.  
\`§4.2\` - Klammern im Namen, um den Besitz eines Ranges vorzutäuschen, sind verboten und können im Extremfall zum Ausschluss führen.  
\`§4.3\` - Sonderzeichen in Namen sind erlaubt, sofern sie nicht gegen unsere Serverregeln verstoßen.  
\`§4.4\` - Avatare dürfen keine beleidigenden, sexuellen, rassistischen oder diskriminierenden Inhalte haben.  
\`§4.5\` - Drogenverherrlichende Avatare sind verboten.  
\`§4.6\` - Avatare, die epileptische Anfälle auslösen können, sind nicht erlaubt.`);
const ticket2Embed = new EmbedBuilder()

  .setColor("#5865f2")

  .setDescription(`
\`§5\`・**Moderation**  
\`§5.1\` - Befolge die Anweisungen der Moderatoren, sie sorgen für einen sicheren und freundlichen Server.  
\`§5.2\` - Melde Regelverstöße oder verdächtiges Verhalten direkt an die Moderatoren.  
\`§5.3\` - Fehlverhalten von Teammitgliedern meldest du bitte der Serverleitung.  
\`§5.4\` - Das Offenlegen der zweiten Identität eines Teammitglieds ist verboten und wird bestraft.  
\`§5.5\` - Das Anfragen von Support durch Nachrichten wie "Bearbeite doch mal mein Ticket" oder "Supporte mal!" ist nicht erwünscht.  
\`§5.6\` - Teammitglieder sind verpflichtet, sich bei Fragen oder Anliegen nur gegenüber der Bereichsleitung zu erklären oder Beweise vorzulegen.
\`§5.7\` - Das Ausnutzen des Ticketsystems (Wiederholtes/grundloses öffnen und schließen) wird bestraft.

\`§6\`・**JTC-Channel und Plugins/Scripte**  
\`§6.1\` - Musikbots, Soundboards oder Stimmverzerrer/Voice-Changer sind nicht erlaubt.  
\`§6.2\` - Bots dürfen nicht als Platzhalter genutzt werden, um einen Channel "am Leben" zu halten.  
\`§6.3\` - Plugins, die das Design des Clients verändern, sind erlaubt.  
\`§6.4\` - Plugins oder VPNs, die die IP verbergen, sind nicht erlaubt. (Bannumgehung)

\`§7\`・**Minecraft Server Regeln**
*Diese Regeln gelten für alle Minecraft Server Projekt von diesem Discord*

\`7.1\` - Modifikationen, die einen unfairen Spielvorteil bieten (z. B. X-Ray, Auto-Aim, Fly-Hacks), sind verboten.
\`7.2\` - Bots, Scripts oder andere automatisierte Programme, die den Spielfluss beeinflussen (z. B. AFK-Farmen oder Auto-Mining), sind nicht erlaubt.
\`7.3\` - Es gelten die gleichen Verhaltens Regeln wie in \`§1\`.
\`§7.4\` - Resource- oder Texture-Packs, die für unfaire Vorteile verwendet werden (z. B. durchsichtige Blöcke), sind untersagt.
\`7.5\` - Griefing und Diebstahl sind verboten, es sei denn, das Server-Projekt erlaubt explizit solche Aktionen (z. B. in Anarchy-Modus).
\`7.6\` - Spawn-Killing, Totem popping oder das gezielte Töten von Spielern ohne Grund ist nicht gestattet, sofern dies nicht Teil des Projekts ist (z. B. PvP-Server).
\`§7.7\` - Exploits, Bugs oder Glitches dürfen nicht absichtlich ausgenutzt werden. Diese sind unverzüglich dem Serverteam zu melden.
\`§7.8\` - Modifikationen wie Freecam, Night Vision oder Map Mods sind erlaubt!
\`§7.9\` - Das Brechen einer der Minecraft Server Regeln kann zu einem Ausschluss vom gesamten Netzwerk führen!


### <:Link:1303373340920119376> - NÜTZLICHE LINKS
› **Webpanel**: https://panel.einfxchpingu.net
› **Status**: https://status.einfxchpingu.net
› **Youtube**: https://www.youtube.com/@EinfxchPingu`);

await interaction.channel.send({ embeds: [ticketEmbed, ticket2Embed]});
await interaction.reply({ content: '`✅`〢Die **Nachricht** wurde erfolgreich **gesendet**!', ephemeral: true });
}
if (choice === 'ticket') {
          const ticketEmbed = new EmbedBuilder()
          .setColor("#5865f2")
          .setDescription(`### <:Ticket:1303373350730596452> × TICKET ERSTELLEN
› **Herzlich Willkommen** im Ticket Support! Wähle unten im **Dropdown-Menü** aus, welche Art von Ticket du **öffnen möchtest**,
und dir wird so **schnell wie Möglich** jemand aus unserem **Moderationsteam** helfen!

### <:hastag:1302715658794176594> - TICKET AUSWAHL

- Allgemeiner Support
- Team Bewerbung
- Gewinn beanspruchen
- Benutzer/Fehler melden
- Problem mit dem Hosting

<:Regelwerk:1303373332690899024> › Das **Ausnutzen** des **Supports** wird bestraft!`);
          const ticketselect = new StringSelectMenuBuilder()
        .setCustomId('ticketselect')
        .setPlaceholder('📌〢Wähle eine Option...')
        .addOptions(
          new StringSelectMenuOptionBuilder()
            .setLabel('Allgemeiner Support')
            .setEmoji('1303382364218593311')
            .setDescription('Klicken mich an um ein Ticket zu öffnen')
            .setValue('support'),
            new StringSelectMenuOptionBuilder()
            .setLabel('Team Bewerbung')
            .setEmoji('1303373355985932358')
            .setDescription('Klicken mich an um ein Ticket zu öffnen')
            .setValue('bewerben'),
            new StringSelectMenuOptionBuilder()
            .setLabel('Gewinn beanspruchen')
            .setEmoji('1303373310528192534')
            .setDescription('Klicken mich an um ein Ticket zu öffnen')
            .setValue('gewinn'),
            new StringSelectMenuOptionBuilder()
            .setLabel('Einen Benutzer/Fehler melden')
            .setEmoji('1303382706830315600')
            .setDescription('Klicken mich an um ein Ticket zu öffnen')
            .setValue('melden'),
            new StringSelectMenuOptionBuilder()
            .setLabel('Problem mit dem Hosting')
            .setEmoji('1303373305973313658')
            .setDescription('Klicken mich an um ein Ticket zu öffnen')
            .setValue('hostingproblem'),
            new StringSelectMenuOptionBuilder()
            .setLabel('Interaktion abbrechen')
            .setEmoji('1303373294094782484')
            .setDescription('Klicken mich an um die Interaktion abzubrechen')
            .setValue('cancel'),
        
        );
        const row = new ActionRowBuilder()
        .addComponents(ticketselect);
        await interaction.channel.send({ embeds: [ticketEmbed], components: [row] });
        await interaction.reply({ content: '`✅`〢Die **Nachricht** wurde erfolgreich **gesendet**!', ephemeral: true });
        }
        if (choice === 'bot') {
          const messageEmbed = new EmbedBuilder()
          .setColor("#5865f2")
          .setDescription(`### <:Server:1303373305973313658> × GRATIS DISCORD BOT & DATENBANK HOSTING!  

Du möchtest deinen **Discord-Bot** hosten? Bei uns bekommst du einen **kostenlosen Server** mit **85 MB RAM** und einer **gratis Datenbank** – perfekt für die meisten Bots!  
Benötigst du mehr Ressourcen? Eröffne einfach ein Ticket in <#1298951101223145472>, und wir helfen dir gerne weiter.  

Möchtest du **mehr RAM oder zusätzliche Server**? Das ist durch **Partnerschaften** oder **Server Boosts** möglich.  

### <:Navigator:1303373297119137853> - SPRACHEN DIE WIR ANBIETEN

- **Java**  
- **Python**  
- **JavaScript**  
- **Typescript** \`NEU\`

### <:Regelwerk:1303373332690899024> - HOSTING REGELN

Das Team behält sich das Recht vor, das Regelwerk anzupassen und Server oder Accounts jederzeit ohne Vorankündigung zu löschen oder zu sperren. Regelverstöße werden entsprechend bestraft.  

\`§1\` - Die Discord-Nutzungsbedingungen und Richtlinien sind einzuhalten. Keine illegalen Bots.  
\`§2\` - Sexuelle Inhalte, Gewalt verherrlichende oder illegale Inhalte sind streng verboten.  
\`§3\` - Spam und das Umgehen von Sperren sind untersagt.  
\`§4\` - Nur Discord-Bots dürfen auf den Servern laufen.  
\`§5\` - Multi-Accounts sind strengstens verboten und führen zur Löschung aller Accounts.  
\`§6\` - Für Schäden an oder durch gehostete Bots übernehmen wir keine Haftung.  
\`§7\` - Pro Server darf nur ein Discord-Bot betrieben werden (keine Multi-Bots).  
\`§8\` - Software, die dem System schadet oder dessen Verfügbarkeit einschränkt, ist verboten.  
\`§9\` - Benutzer sind selbst für Backups ihrer Server verantwortlich. Wir haften nicht für Datenverluste.  
\`§10\` - Für das Hosting sind ein Benutzername und eine gültige E-Mail-Adresse erforderlich.  
\`§11\` - Das Team behält sich das Recht vor, Server oder Accounts jederzeit ohne Vorwarnung zu löschen oder zu sperren.  
\`§12\` - Wer den Discord-Server nach der Servererstellung verlässt, verliert seinen Server und Account.  
\`§13\` - Server, die länger als zwei Wochen inaktiv sind, werden gesperrt.  
\`§14\` - Gesperrte Server können über den Ticket-Support entsperrt werden. Nach einer Woche ohne Reaktion wird der Server gelöscht.  
\`§15\` - Die bereitgestellte Datenbank darf nur für den gehosteten Discord-Bot oder Bots im Netzwerk verwendet werden.  

### <:Information:1303373343705010216> - SONSTIGES

› Wir **geben** deine **Daten __nicht__** an **Dritte weiter**! **Fehler** müssen **gemeldet** werden. **Klicke** unten auf den **Button** "Jetzt Server mieten" um einen **kostenlosen Server** zu **erhalten**.`);

const hostinButton = new ButtonBuilder()
.setCustomId('hosting')
.setLabel(' - Jetzt Server mieten')
.setEmoji('1303373305973313658')
.setStyle(ButtonStyle.Secondary);

const hostingRow = new ActionRowBuilder()
.addComponents(hostinButton);
        
        await interaction.channel.send({ embeds: [messageEmbed], components: [hostingRow]});
        await interaction.reply({ content: '`✅`〢Die **Nachricht** wurde erfolgreich **gesendet**!', ephemeral: true });
        }
        if (choice === 'boosts') {
          const messageEmbed = new EmbedBuilder()
          .setColor("#5865f2")
          .setDescription(`### <:Rackete:1303373302818930738> × BOOST VORTEILE
› **Danke** an jeden **Server Booster**! Mit jedem **Boost** helft ihr uns dabei, unseren **Server** auf das **nächste** Level zu bringen und **exklusive** Vorteile für die gesamte **Community** zu ermöglichen!

### <:Sterne:1303373321244639242>  - DEINE VORTEILE

- Die Rolle <@&1302670952798224425> *
-  **Pro Boost** einen weiteren **Server.** *
- In dem **nächsten Video** wirst du **gegrüßt**!
- **Pro Boost** ein **custom Emoji** deiner Wahl, welches dem **Server** hinzugefügt wird.

**Beachte** das die mit einem * gekennzeichneten Belohnungen nur solange halten, wie auch der/die Boost aktiv sind`);

        await interaction.channel.send({ embeds: [messageEmbed]});
        await interaction.reply({ content: '`✅`〢Die **Nachricht** wurde erfolgreich **gesendet**!', ephemeral: true });
        }
        if (choice === 'hostingnest') {
          const hostingNestWerbungEmbed = new EmbedBuilder()
          .setColor("#5865f2")
          .setDescription(`### <:Server:1303373305973313658> × HOSTINGNEST
› Du suchst einen **Server** wo man sich über **Technick**, **Coding** und **Video-Spiele** oder in verschieden **Sprachen** unterhalten kann? Dann bist du hier genau richtig. Wir **bieten** noch vieles mehr, als nur **Server Hosting**:

 <:Partner:1303373291096113207> Partnerschaften ab 120 Member (Stufensystem)
<:Sterne:1303373321244639242> Eine Freundliche Community
<:Bot:1303373287962710062> Verschiedene Minispiele
<:Team:1303373355985932358> Nette und freundliche Teammitglieder

<:DCBot:1303373361291726968> Eigener Bot mit vielen Funktionen
<:Netzwerk:1303373318111498350> Wir nutzen unser eigenes Netzwerk
<:Navigator:1303373297119137853> Bald unser eigener Minecraft Server.
<:Developer_Coding:1299810594387398788> Wir bieten Server aller Art an.

› Schau **unbedingt** mal bei **HostingNest** vorbei!`);

const websiteButton = new ButtonBuilder()
.setURL('https://hostingnest.de')
.setLabel(' - Offizielle Website')
.setEmoji('1303373318111498350')
.setStyle(ButtonStyle.Link);

const discordButton = new ButtonBuilder()
.setURL('https://discord.gg/jSNaKUdyB3')
.setLabel(' - Discord Server')
.setEmoji('1302714862706888806')
.setStyle(ButtonStyle.Link);

const hostingRow = new ActionRowBuilder()
.addComponents(websiteButton, discordButton);
        
        await interaction.channel.send({ embeds: [hostingNestWerbungEmbed], components:[hostingRow]});
        await interaction.reply({ content: '`✅`〢Die **Nachricht** wurde erfolgreich **gesendet**!', ephemeral: true });
        }
    } catch (error) {
      console.error(error);
      await interaction.reply({ content: '`❌`〢Es ist ein **Fehler** aufgetreten. Bitte versuche es **später erneut**.', ephemeral: true });
    }
  }
};
