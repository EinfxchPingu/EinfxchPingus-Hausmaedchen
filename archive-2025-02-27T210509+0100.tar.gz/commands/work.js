const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

const dataPath = path.join(__dirname, '..', 'config', 'data', 'casino.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('work')
        .setDescription('💼〢Arbeite und verdiene Geld!'),
    async execute(interaction) {
        const userId = interaction.user.id;
        const cooldownTime = 30 * 60 * 1000; 
        const now = Date.now();

        let data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
        if (!data[userId]) data[userId] = { work: 0, slut: 0, crime: 0, bank: 0 };

        if (now - data[userId].work < cooldownTime) {
            const nextAvailableTime = data[userId].work + cooldownTime;

            return interaction.reply({ content:`\`❌\`〢Ein **Cooldown** ist **Aktiv**. Du kannst erst um <t:${Math.floor(nextAvailableTime / 1000)}:T> wieder Geld verdienen!`, ephemeral: true });
        }
        
        data[userId].work = now;
        fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));

        const reward = Math.floor(Math.random() * 100) + 50;
        const embed = new EmbedBuilder()
        	.setColor("#5865f2")
            .setDescription(`### <:Team:1303373355985932358> × ARBEIT ABGESCHLOSSEN
› Du hast hart gearbeitet und **${reward} Coins** verdient!`);
        
        data[userId].balance += reward; 
fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));


        await interaction.reply({ embeds: [embed] });
    },
};
