const { SlashCommandBuilder } = require('@discordjs/builders');
const { EmbedBuilder, PermissionsBitField } = require('discord.js');
const fs = require('fs');
const path = require('path');
const dataFilePath = path.join(__dirname, '..', 'config', 'data', 'invites.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('invites')
    .setDMPermission(false)
    .setDescription('🔗〢Zeigt deine Einladungen oder die von anderen an.')
    .addUserOption(option =>
      option.setName('user').setDescription('👤〢Von wem die Einladungen?').setRequired(false)
    ),
  async execute(interaction) {
    try {
      const data = JSON.parse(fs.readFileSync(dataFilePath, 'utf8'));

      const user = interaction.options.getUser('user') || interaction.user;
      const userData = data[user.id] || { total: 0, left: 0 };

      if (userData.total === 0 && userData.left === 0) {
        return interaction.reply({ content: '`❌`〢Der **Benutzer** hat noch **keine** Einladungen.', ephemeral: true });
      }

      const embed = new EmbedBuilder()
        .setColor("#5865f2")
        .setTitle(`<:Link:1303373340920119376> × ${user.globalName || user.username}'s Einladungen`)
        .setDescription(`**Insgesamt eingeladen:** \`${userData.total}\`\n**Davon haben verlassen:** \`${userData.left}\`\n\n**Einladungen:** \`${userData.total - userData.left}\``);

      await interaction.reply({ embeds: [embed] });
    } catch (error) {
      console.error(error);
      await interaction.reply({ content: '`❌`〢Es ist ein **Fehler** aufgetreten. Bitte versuche es **später erneut**.', ephemeral: true });
    }
  }
};
