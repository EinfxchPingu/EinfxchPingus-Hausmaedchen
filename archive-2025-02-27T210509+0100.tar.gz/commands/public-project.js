const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('public-project')
        .setDescription('🎨〢Veröffentliche ein neues Projekt!')
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
        .addStringOption(option =>
            option.setName('title')
                .setDescription('📋〢Titel des Projekts')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('description')
                .setDescription('📋〢Beschreibung des Projekts')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('link')
                .setDescription('🔗〢Der Download-Link')
                .setRequired(true)),

    async execute(interaction) {
        const title = interaction.options.getString('title');
        const description = interaction.options.getString('description');
        const link = interaction.options.getString('link');
        const targetChannelId = '1313468806034886698';

        const projectsPath = path.join(__dirname, '../config/data/public-projects.json');

        let projects = [];
        if (fs.existsSync(projectsPath)) {
            projects = JSON.parse(fs.readFileSync(projectsPath, 'utf8'));
        }

        const embed = new EmbedBuilder()
            .setDescription(`### <:Developer_Coding:1299810594387398788> × NEUES PROJEKT VERÖFFENTLICHT

**${title}**
> ${description}

**WICHTIG**: Du benötigst die Rolle <@&1313126660173856790>, um dieses Projekt herunterladen zu können!`)
            .setColor("#5865f2");

        const button = new ButtonBuilder()
            .setCustomId('download_project')
            .setLabel('- Projekt herunterladen')
            .setEmoji('1304086567509561487')
            .setStyle(ButtonStyle.Secondary);

        const row = new ActionRowBuilder().addComponents(button);

        const targetChannel = await interaction.client.channels.fetch(targetChannelId);
        if (!targetChannel || !targetChannel.isTextBased()) {
            return interaction.reply({ content: 'Fehler: Zielkanal nicht gefunden oder nicht gültig!', ephemeral: true });
        }

        const message = await targetChannel.send({ embeds: [embed], components: [row] });

        projects.push({ 
            title, 
            description, 
            link, 
            messageId: message.id 
        });

        fs.writeFileSync(projectsPath, JSON.stringify(projects, null, 2));

        await interaction.reply({ content: '`✅`〢Dein Projekt wurde veröffentlicht!', ephemeral: true });
    },
};
