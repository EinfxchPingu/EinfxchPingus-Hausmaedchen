const { SlashCommandBuilder } = require('@discordjs/builders');
const { EmbedBuilder } = require('discord.js');
const path = require('path');
const fs = require('fs');

const levelFilePath = path.join(__dirname, '..', 'config', 'data', 'level.json');
const moneyFilePath = path.join(__dirname, '..', 'config', 'data', 'casino.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('leaderboard')
    .setDescription('??〢Zeige das gewünschte Leaderboard an.')
    .addStringOption(option =>
      option
        .setName('option')
        .setDescription('⭐〢Wähle das Leaderboard aus.')
        .setRequired(true)
        .addChoices(
          { name: '⭐ - Level', value: 'level' },
          { name: '💰 - Geld (Bank + Bar)', value: 'money' }
        )
    ),
  async execute(interaction) {
    try {
      const option = interaction.options.getString('option');
      let leaderboard, embed;

      if (option === 'level') {
        const levelData = JSON.parse(fs.readFileSync(levelFilePath, 'utf-8'));
        const usersWithStats = levelData.level.users.filter(user => !user.hideStats);
        if (usersWithStats.length === 0) {
          return interaction.reply({ content: '`❌`〢Es wurden **keine Daten** für diesen **Server** gefunden.', ephemeral: true });
        }
        
        const sortedUsers = levelData.level.users
          .sort((a, b) => (b.level === a.level ? b.xp - a.xp : b.level - a.level))
          .slice(0, 10);

        leaderboard = sortedUsers.map((user, index) => {
          return `**${index + 1}**. <@${user.userid}> - **Level ${user.level}**`;
        });

        embed = new EmbedBuilder()
          .setColor('#5865f2')
          .setTitle('<:Stern:1303373346398015530> × TOP 10 LEVEL LEADERBOARD')
          .setDescription(`› **Wie du XP sammeln kannst**:
> - **Pro Nachricht**: 15XP
> - **Pro Minute im Talk**: 3XP
> - **Pro Server Boost**: 200XP
          
` + leaderboard.join('\n'));
      }

      if (option === 'money') {
        const moneyData = JSON.parse(fs.readFileSync(moneyFilePath, 'utf-8'));
        const topUsers = Object.entries(moneyData)
          .map(([userid, user]) => ({
            userid,
            totalMoney: user.balance + user.bank,
          }))
          .sort((a, b) => b.totalMoney - a.totalMoney)
          .slice(0, 10);

        if (topUsers.length === 0) {
          return interaction.reply({ content: '`❌`〢Es wurden **keine Daten** gefunden.', ephemeral: true });
        }

        leaderboard = topUsers
          .map((user, index) => `**${index + 1}.** <@${user.userid}> — **${user.totalMoney}** 💰`)
          .join('\n');

        embed = new EmbedBuilder()
          .setColor('#5865f2')
          .setTitle('<:emoji_140:1313943323836416072> × TOP 10 MONEY LEADERBOARD')
          .setDescription(leaderboard);
      }

      return interaction.reply({ embeds: [embed] });
    } catch (error) {
      console.error(error);
      return interaction.reply({ content: '`❌`〢Es ist ein **Fehler** aufgetreten. Bitte versuche es **später erneut**.', ephemeral: true });
    }
  },
};
