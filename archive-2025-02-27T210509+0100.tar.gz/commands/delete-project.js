const { SlashCommandBuilder } = require('@discordjs/builders');
const path = require("path");
const projectPath = path.join(__dirname, '..', 'config', 'data', 'projects.json');
let data = require(projectPath);
const fs = require('fs');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('delete-project')
        .setDMPermission(false)
        .setDescription('🗑️〢Lösche dein eingereichtes Projekt'),

    async execute(interaction) {
        const userId = interaction.user.id;

        if (!data.users || !data.users[userId] || !data.users[userId].projects || data.users[userId].projects.length === 0) {
            return interaction.reply({
                content: `\`⚠️\`〢Du hast **aktuell kein** Projekt, das **gelöscht** werden kann.`,
                ephemeral: true
            });
        }

        const project = data.users[userId].projects[0];
        const postId = project.postId;

        try {
            const forumChannel = await interaction.guild.channels.fetch("1302556550099107880");
            const thread = await forumChannel.threads.fetch(postId);

            if (thread) {
                await thread.delete();
                interaction.reply({
                    content: `\`✅\`〢Dein **Projekt** wurde erfolgreich **gelöscht**.`,
                    ephemeral: true
                });
                
                data.users[userId].projects = [];
                fs.writeFileSync(projectPath, JSON.stringify(data, null, 2));
            } else {
                interaction.reply({
                    content: `\`⚠️\`〢Der **Projekt-Post** konnte nicht **gefunden** werden.`,
                    ephemeral: true
                });
            }
        } catch (error) {
            console.error("Fehler beim Löschen des Projekts:", error);
            interaction.reply({
                content: `\`❌\`〢Es gab einen **Fehler** beim **Löschen** deines **Projekts**.`,
                ephemeral: true
            });
        }
    },
};
