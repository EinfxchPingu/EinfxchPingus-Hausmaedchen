const { Client, GatewayIntentBits, Partials, ActivityType, ButtonBuilder, ButtonStyle, ChannelType, ModalBuilder, TextInputBuilder, TextInputStyle, PermissionsBitField, EmbedBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, ActionRowBuilder, REST, Routes, Collection, GuildNSFWLevel } = require('discord.js');
const path = require('path');
const axios = require("axios");
const fs = require('fs');
const countingDataPath = path.join(__dirname, 'config', 'data', 'counting.json');
const gwPath = path.join(__dirname, 'config', 'data', 'gw.json');
let gw = require(gwPath);
const InviteManager = require('discord-invite');
const crypto = require('crypto');

const INVITE_FILE = path.join(__dirname, 'config', 'data', 'invites.json');
const ANNOUNCE_CHANNEL_ID = '1298922464591609926';


const configPath = path.join(__dirname, 'config', 'config.json');
let config = require(configPath);

const STREAK_FILE = path.join(__dirname, 'config', 'data', 'streak.json');

if (!fs.existsSync(path.dirname(STREAK_FILE))) {
    fs.mkdirSync(path.dirname(STREAK_FILE), { recursive: true });
}

if (!fs.existsSync(STREAK_FILE)) {
    fs.writeFileSync(STREAK_FILE, JSON.stringify({}));
}

const ticketPath = path.join(__dirname, 'config', 'data', 'ticket.json');
let tickets = require(ticketPath);

const levelPath = path.join(__dirname, 'config', 'data', 'level.json');
let level = require(levelPath);

const hostingPath = path.join(__dirname, 'config', 'data', 'hosting.json');
let hosting = require(hostingPath);

const dataPath = path.join(__dirname, 'config', 'data', 'partner.json');

if (!gw) {
  gw = { giveaways: [], history: [] };
  fs.writeFileSync(gwPath, JSON.stringify(gw, null, 2));
}

try {
  tickets = require(ticketPath);
} catch (error) {
  tickets = { tickets: [] };
  fs.writeFileSync(ticketPath, JSON.stringify(tickets, null, 2));
}

if (!config) {
  config = [];
  fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
}

function formatDateInBerlinTimezone(date) {
  const berlinTimezone = 'Europe/Berlin';
  return new Date(date).toLocaleString('de-DE', { timeZone: berlinTimezone });
}

const client = new Client({
  intents: Object.keys(GatewayIntentBits).map(a => GatewayIntentBits[a]),
  partials: [Partials.Channel],
});

function loadStreaks() {
    if (!fs.existsSync(STREAK_FILE)) {
        return {};
    }
    try {
        return JSON.parse(fs.readFileSync(STREAK_FILE, 'utf8'));
    } catch (error) {
        console.error("Fehler beim Laden der Streak-Datei:", error);
        return {};
    }
}

function saveStreaks(data) {
    fs.writeFileSync(STREAK_FILE, JSON.stringify(data, null, 2));
}

function isExpired(lastMessageTimestamp) {
    const now = Date.now();
    return now - lastMessageTimestamp > 24 * 60 * 60 * 1000;
}

function hasSentMessageToday(lastMessageDate) {
    const now = new Date();
    const lastDate = new Date(lastMessageDate);
    return (
        now.getFullYear() === lastDate.getFullYear() &&
        now.getMonth() === lastDate.getMonth() &&
        now.getDate() === lastDate.getDate()
    );
}


const CLASHAI_API_KEY = config.apitoken;

client.on('messageCreate', async (message) => {
    if (message.channel.id === "1317894815085629501" && !message.author.bot) {
        try {
            message.channel.sendTyping();
            if (message.mentions.everyone || message.mentions.users.size > 0 || message.mentions.roles.size > 0) {
                return message.reply("Damit kann ich dir leider nicht weiterhelfen.");
            }

            const username = message.author.username;
            

            const url = 'https://api.clashai.eu/v1/chat/completions';
            const payload = {
                model: "gpt-4o-mini",
                messages: [
                    { role: "system", content: "Du bist ein freundlicher Bot, der locker, etwas cool und humorvoll auf Deutsch spricht. Wenn Nötig auch Englisch. Über sensible Themen wie sexuelle oder Drogen-Themen zu sprechen ist dir verboten. Beachte auch bei nachfrage welchen Tag wir haben das Datum an dem die Nachricht gesendet wurde" },
                    { role: "user", content: `Die Nachricht von ${username} am ${formatDateInBerlinTimezone(new Date())}: ${message.content}` }
                ]
            };

            const headers = {
                'Authorization': `Bearer ${CLASHAI_API_KEY}`
            };

            const response = await axios.post(url, payload, { headers });

            if (response.status === 200) {
                let reply = response.data.choices[0].message.content;
                reply = reply.replace(/@everyone|@here|@/g, ' ');
                message.reply(reply);
            } else {
                message.reply("Ups, da ist etwas schiefgelaufen. Versuch es später nochmal!");
            }
        } catch (error) {
            message.reply("Ich kann dir leider mit deiner Frage nicht weiterhelfen!");
        }
    }
});

async function checkStreaks() {
    const streaks = loadStreaks();
    const now = Date.now();

    for (const [userId, data] of Object.entries(streaks)) {
        if (isExpired(data.lastMessageTimestamp)) {
            streaks[userId].streak = 0;

            const user = await client.users.fetch(userId).catch(() => null);
            if (user) {
                user.send('`🚀`〢Deine **Streak** wurde **zurückgesetzt**, weil du länger als **24 Stunden** inaktiv **warst**!');
            }
        }
    }

    saveStreaks(streaks);
}


const invClient = new InviteManager(client);

const loadInvites = () => fs.existsSync(INVITE_FILE) ? JSON.parse(fs.readFileSync(INVITE_FILE, 'utf8')) : {};
const saveInvites = (data) => fs.writeFileSync(INVITE_FILE, JSON.stringify(data, null, 2), 'utf8');

let inviteData = loadInvites();

client.on('memberJoin', async (member, inviter) => {
    const channel = member.guild.channels.cache.get(ANNOUNCE_CHANNEL_ID);
    if (!channel) return;

    if (!inviter) {
        channel.send(`**<:Flugzeug:1303373336050667541> × <@${member.user.id}> *(${member.user.username})* ist dem Server beigetreten, aber der Einladende konnte nicht gefunden werden.`);
    } else if (member.id === inviter.id) {
        channel.send(`<:Flugzeug:1303373336050667541> × <@${member.user.id}> *(${member.user.username})* hat sich selbst eingeladen!`);
    } else if (member.guild.vanityURLCode === inviter) {
        channel.send(`<:Flugzeug:1303373336050667541> × <@${member.user.id}> *(${member.user.username})* ist über die Vanity-URL beigetreten.`);
    } else {
        inviteData[inviter.id] = inviteData[inviter.id] || { total: 0, left: 0 };
        inviteData[inviter.id].total++;
        saveInvites(inviteData);
        channel.send(`<:Flugzeug:1303373336050667541> × <@${member.user.id}> *(${member.user.username})* ist beigetreten! Eingeladen von <@${inviter.id}> *(${inviter.username})*`);
    }
});

client.on('memberLeave', async (member, inviter) => {
    const channel = member.guild.channels.cache.get(ANNOUNCE_CHANNEL_ID);
    if (!channel) return;

    if (!inviter) {
        channel.send(`<:Flugzeug:1303373336050667541> × <@${member.user.id}> *(${member.user.username})* hat den Server verlassen, aber der Einladende konnte nicht gefunden werden.`);
    } else if (member.id === inviter.id) {
        channel.send(`<:Flugzeug:1303373336050667541> × <@${member.user.id}> *(${member.user.username})* hat den Server verlassen, nachdem er sich selbst eingeladen hat.`);
    } else if (member.guild.vanityURLCode === inviter) {
        channel.send(`<:Flugzeug:1303373336050667541> × <@${member.user.id}> *(${member.user.username})* hat den Server über die Vanity-URL verlassen.`);
    } else if (inviteData[inviter.id]) {
        inviteData[inviter.id].left++;
        saveInvites(inviteData);
        channel.send(`<:Flugzeug:1303373336050667541> × <@${member.user.id}> *(${member.user.username})* hat den Server verlassen! Eingeladen von <@${inviter.id}> *(${inviter.username})*`);
    }
});


client.on('interactionCreate', async interaction => {
    if (!interaction.isButton()) return;

    if (interaction.customId === 'download_project') {
        const requiredRoleId = '1313126660173856790';
        const projectsPath = path.join(__dirname, './config/data/public-projects.json');

        if (!fs.existsSync(projectsPath)) {
            return interaction.reply({ content: '`❌`〢Es sind **keine** Projekte **verfügbar**.', ephemeral: true });
        }

        const projects = JSON.parse(fs.readFileSync(projectsPath, 'utf8'));

        const project = projects.find(p => p.messageId === interaction.message.id);

        if (!project) {
            return interaction.reply({ content: '`❌`〢**Projekt** nicht gefunden.', ephemeral: true });
        }

        if (!interaction.member.roles.cache.has(requiredRoleId)) {
            return interaction.reply({ 
                content: '`❌`〢Du **benötigst** mindestens **3 Invites**, um dieses **Projekt** herunterladen zu **können**!', 
                ephemeral: true 
            });
        }

        return interaction.reply({
            content: `\`📥\`〢Hier ist der **Download-Link** für [**${project.title}**](${project.link})`,
            ephemeral: true,
        });
    }
});

const clientId = config.clientId;
const token = config.token;

client.on('messageCreate', async (message) => {
if (message.channel.type === ChannelType.GuildAnnouncement && message.author.bot) {
try {         
await message.crosspost();
        } catch (error) {         
        }

    }

});



const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

async function endGiveaway(giveaway) {
  const channel = await client.channels.fetch(giveaway.channelId);
  if (!channel) return;

  const message = await channel.messages.fetch(giveaway.messageId);
  if (!message) return;

  const winnerCount = giveaway.winners;
  const totalParticipants = giveaway.participants.length;

  if (totalParticipants < winnerCount) {
    const embed = new EmbedBuilder()
    .setDescription(`### <:Geschenk:1303373310528192534> × GEWINNSPIEL VORBEI
› Preis: **${giveaway.prize}**

### <:Datei:1303373300554272789> - DETAILS
- Teilnehmer: **${totalParticipants}**
- Erstellt von: <@${giveaway.creator}>

› Es gab nicht genügend Teilnehmer. Das Gewinnspiel wurde beendet.`)
    .setColor('#5865f2');

    await message.edit({ embeds: [embed], components: [] });
  } else {
    const winners = [];
    for (let i = 0; i < winnerCount; i++) {
      const winnerIndex = Math.floor(Math.random() * giveaway.participants.length);
      winners.push(giveaway.participants.splice(winnerIndex, 1)[0]);
    }

    const embed = new EmbedBuilder()
    .setDescription(`### <:Geschenk:1303373310528192534> × GEWINNSPIEL VORBEI
      
› Preis: **${giveaway.prize}**

### <:Datei:1303373300554272789> - DETAILS
- Teilnehmer: **${totalParticipants}**
- Gewinner: ${winners.map(id => `<@${id}>`).join('\n')}
- Erstellt von: <@${giveaway.creator}>`)
    .setColor('#5865f2');

    const winnerEmbed = new EmbedBuilder()
    .setDescription(`### <:Geschenk:1303373310528192534> × GLÜCKWUNSCH
      › ${winners.map(id => `<@${id}>`).join(' ')}, du hast **${giveaway.prize}** gewonnen!`)
    .setColor('#5865f2');
    await message.edit({ embeds: [embed], components: [] });
    await message.channel.send({embeds:[winnerEmbed]})
  }

  gw.history.push(giveaway);
  gw.giveaways = gw.giveaways.filter(g => g.id !== giveaway.id);
  fs.writeFileSync(gwPath, JSON.stringify(gw, null, 2));
}


async function giveawayLoop() {
  while (true) {
    const now = Date.now();
    for (const giveaway of gw.giveaways) {
      if (now >= giveaway.endTime) {
        await endGiveaway(giveaway);
      }
    }
    await sleep(3000);
  }
}


async function sendEmbedMessage() {
  try {
    const channel = await client.channels.fetch('1307093259503407166');
    const unsere_werbung = channel.send({ content:`## <:Developer_Coding:1299810594387398788>〢EinfxchPingu × Coding & Gratis Hosting
› Tritt einer **engagierten Community** bei, die sich auf **Coding**, **Tutorials** und **entspanntes Zusammensein** spezialisiert hat.

### <:Sterne:1303373321244639242> - WAS DICH ERWARTET
<:Server:1303373305973313658> **Kostenloses Bot & Datenbank-Hosting für** deine **Projekte**
<:Developer_Coding:1299810594387398788>  Freundliche **Unterstützung** bei allen **Coding-Fragen**
<:emoji_135:1304110746476609626> Eine **hilfsbereite** Community mit echtem **Zusammenhalt**
<:DCBot:1303373361291726968> **Eigene Bots** und viele **coole Features** für alle Mitglieder
<:cam:1299810456382214217> Ein **YouTube Kanal** mit zahlreichen **Tutorials** und mehr
<:Rackete:1303373302818930738> Viel **Unterhaltung** und **Minigames**
<:Geschenk:1303373310528192534> Häufige **Events** und **Gewinnspiele**

<:Sterne:1303373321244639242> › Schau **vorbei** und **werde** Teil einer **Community**, die sowohl dein **Wissen** als auch deine **Projekte** wachsen lässt!
https://discord.gg/einfxchpingu` });
  } catch (error) {
    console.error('Fehler beim Senden der Nachricht:', error);
  }
}

function checkAndSetTime() {
  const currentTime = Date.now();
  const data = fs.existsSync(dataPath) ? require(dataPath) : {};

  if (!data.lastSent || currentTime - data.lastSent >= 2 * 60 * 60 * 1000) {
    sendEmbedMessage();
    data.lastSent = currentTime; 
    fs.writeFileSync(dataPath, JSON.stringify(data, null, 2)); 
  }
}

client.once('ready', async () => {
  console.log(`Bot eingeloggt als ${client.user.tag}`);
  console.log(`Zeitzone gesetzt auf Europe/Berlin (${formatDateInBerlinTimezone(new Date())})`);
  giveawayLoop();
  checkAndSetTime();
  setInterval(checkAndSetTime, 6 * 60 * 60 * 1000);
   
  let totalUsers = 0;


    for (const guild of client.guilds.cache.values()) {
        await guild.members.fetch(); 
        totalUsers += guild.memberCount;
    }

  client.user.setPresence({
    activities: [{ name: `👥 - ${totalUsers} Mitgliedern zu`, type: ActivityType.Watching }],
    status: 'online',
  });
});

client.commands = new Map();

const commandFiles = fs.readdirSync('./commands').filter(file => file.endsWith('.js'));

for (const file of commandFiles) {
  const command = require(`./commands/${file}`);
  client.commands.set(command.data.name, command);
}

const rest = new REST({ version: '9' }).setToken(token);

(async () => {
  try {
    console.log('Aktualisiere die Slash Commands (/)');

    await rest.put(
      Routes.applicationCommands(clientId),
      { body: [...client.commands.values()].map(command => command.data.toJSON()) },
    );

    console.log('Alle Slash Commands (/) wurden erfolgreich geladen');
  } catch (error) {
    console.error(error);
  }
})();

client.on('interactionCreate', async interaction => {
  if (!interaction.isCommand()) return;

  const { commandName } = interaction;

  if (!client.commands.has(commandName)) return;

  try {
    await client.commands.get(commandName).execute(interaction);
  } catch (error) {
    console.log(error);
    await interaction.reply({ content: '`❌`〢Es ist ein **Fehler** aufgetreten! Bitte melde **folgendes** einem Administrator:``` ' + error + "```", ephemeral: true });
  }
});



const roleAchievements = {
  "1298794609672982591": { name: "BUG HUNTER", color: "#FFECA1", description: `### <:Schilder:1303373314986741800> × NEUEN ERFOLG FREIGESCHALTET

› **Herzlichen Glückwunsch zu deinem Erfolg!** Der Weg war vielleicht **nicht einfach**, aber jetzt hast du es **geschafft**!

- **Erfolg freigeschaltet:** \`🛟 | BADGE - BUG HUNTER\`
- Als **Dank** für deine **Hilfe** uns **Fehler** des **Systems** zu zuschicken, erhälst du eine **einzigarte Rolle**!

<:Sterne:1303373321244639242> › Schalte **noch mehr** Erfolge frei, um eine **einzigartige** Rolle zu erhalten!` },
  "1298794848647778415": { name: "1 JAHRES MITGLIED", color: "#FFECA1", description: `### <:Schilder:1303373314986741800> × NEUEN ERFOLG FREIGESCHALTET

› **Herzlichen Glückwunsch zu deinem Erfolg!** Der Weg war vielleicht **nicht einfach**, aber jetzt hast du es **geschafft**!

- **Erfolg freigeschaltet:** \`🔥 | BADGE - 1 JAHRES MITGLIED\`
- **WOW**! **1 Jahr** ist es jetzt schon **her**, dass du dich uns **angeschlossen** hast. **Auf viele weitere Jahre**!

<:Sterne:1303373321244639242> › Schalte **noch mehr** Erfolge frei, um eine **einzigartige** Rolle zu erhalten!` },
  "1301993246611996702": { name: "TEIL DES RATES", color: "#FFECA1", description: `### <:Schilder:1303373314986741800> × NEUEN ERFOLG FREIGESCHALTET

› **Herzlichen Glückwunsch zu deinem Erfolg!** Der Weg war vielleicht **nicht einfach**, aber jetzt hast du es **geschafft**!

- **Erfolg freigeschaltet:** \`📚 | BADGE - TEIL DES RATES\`
- **Du** hast jetzt schon an **15 Umfragen** teilgenommen und **zeigst echtes Engagement** in unserer **Community**!

<:Sterne:1303373321244639242> › Schalte **noch mehr** Erfolge frei, um eine **einzigartige** Rolle zu erhalten!` },
  "1298795667887493140": { name: "LVL MAX", color: "#FFECA1", description: `### <:Schilder:1303373314986741800> × NEUEN ERFOLG FREIGESCHALTET

› **Herzlichen Glückwunsch zu deinem Erfolg!** Der Weg war vielleicht **nicht einfach**, aber jetzt hast du es **geschafft**!

- **Erfolg freigeschaltet:** \`🏆 | BADGE - LVL MAX\`
- **Du** hast das **Maximale Chat-Level** erreicht und als **Belohnung** deiner **Aktivität** diese Rolle **erhalten**.

<:Sterne:1303373321244639242> › Schalte **noch mehr** Erfolge frei, um eine **einzigartige** Rolle zu erhalten!` },
  "1298940456830369873": { name: "HOSTING4FREE", color: "#FFECA1", description: `### <:Schilder:1303373314986741800> × NEUEN ERFOLG FREIGESCHALTET

› **Herzlichen Glückwunsch zu deinem Erfolg!** Der Weg war vielleicht **nicht einfach**, aber jetzt hast du es **geschafft**!

- **Erfolg freigeschaltet:** \`📡 | BADGE - HOSTING4FREE\`
- **Neben** dem **kostenlosen Server**, erhälst du noch eine **einzigarte Rolle**. **Danke**, dass du uns deinen Bot **anvertraust**!

<:Sterne:1303373321244639242> › Schalte **noch mehr** Erfolge frei, um eine **einzigartige** Rolle zu erhalten!` }
};
const specialRoleId = "1301529689466343474";

client.on('guildMemberUpdate', async (oldMember, newMember) => {
  const userId = newMember.id;
  const addedRoles = newMember.roles.cache.filter(role => !oldMember.roles.cache.has(role.id));
  const achievements = loadAchievements();

  addedRoles.forEach(role => {
      if (roleAchievements[role.id]) {
          if (!achievements[userId]) achievements[userId] = [];
          if (!achievements[userId].includes(role.id)) {
              achievements[userId].push(role.id);
              saveAchievements(achievements);

              const achievement = roleAchievements[role.id];
              const embed = new EmbedBuilder()
                  .setDescription(achievement.description)
                  .setColor(achievement.color);

              newMember.send({ embeds: [embed] }).catch(console.error);

              if (hasAllAchievements(achievements[userId])) {
                  newMember.roles.add(specialRoleId).catch(console.error);
                  const specialEmbed = new EmbedBuilder()
                      .setDescription(`### <:Sterne:1303373321244639242> × GEHEIMEN ERFOLG FREIGESCHALTET

› **Herzlichen Glückwunsch zu deinem Erfolg!** Der Weg war vielleicht **nicht einfach**, aber jetzt hast du es **geschafft**!

- **Erfolg freigeschaltet:** \`🏹 × ERFOLGEN-JÄGER\`
- **Du** hast **alle Erfolge** gesammelt und hast **dir** diese **einzigartige Rolle** wirklich **verdient**!

<:Schilder:1303373314986741800> › **Danke**, das du dich uns **angeschlossen** hast und so **aktiv** warst`)
                      .setColor("#FFECA1");
                  newMember.send({ embeds: [specialEmbed] }).catch(console.error);
              }
          }
      }
  });
});

function hasAllAchievements(userAchievements) {
  return Object.keys(roleAchievements).every(roleId => userAchievements.includes(roleId));
}

function loadAchievements() {
  try {
      return JSON.parse(fs.readFileSync('config/data/achievements.json', 'utf8'));
  } catch (err) {
      console.error("Fehler beim Laden der Achievements:", err);
      return {};
  }
}

function saveAchievements(data) {
  fs.writeFileSync('config/data/achievements.json', JSON.stringify(data, null, 2), 'utf8');
}

const baseXP = 100;
const xpPerLevelMultiplier = 1.18;

const ROLE_IDS = ['1299607122413096980', '1298937622814789713', "1298799404316098580", "1298795497154150400", "1298787551083102248", "1298789570481094666"];


client.on('guildMemberAdd', async (member) => {
    try {
      const messageEmbed = new EmbedBuilder()
      .setColor("#5865f2")
      .setDescription(`### <:4020_blurple_wave:1303716667704082462> × WILLKOMMEN AUF DEM SERVER
› Herzlich Willkommen bei einer **engagierten Community** bei, die sich auf **Coding**, **Tutorials** und **entspanntes Zusammensein** spezialisiert hat.

### <:Sterne:1303373321244639242> - WAS DICH ERWARTET
- <:Server:1303373305973313658> **Kostenloses** Bot-Hosting für deine Projekte
- <:Developer_Coding:1299810594387398788>  Freundliche **Unterstützung** bei allen **Coding-Fragen**
- <:emoji_135:1304110746476609626> Eine **hilfsbereite** Community mit echtem **Zusammenhalt**
- <:DCBot:1303373361291726968> **Eigene Bots** und viele **coole Features** für alle Mitglieder
- <:cam:1299810456382214217> Ein **YouTube Kanal** mit zahlreichen **Tutorials** und mehr
- <:Rackete:1303373302818930738> Viel **Unterhaltung** und **Minigames**
- <:Geschenk:1303373310528192534> Häufige **Events** und **Gewinnspiele**

› **Danke**, dass du uns eine **Chance** gibst und dich uns **angeschlossen** hast!`);

const erfolgEmbed = new EmbedBuilder()
.setColor("#5865f2")
.setDescription(`### <:Schilder:1303373314986741800> × NEUEN ERFOLG FREIGESCHALTET

› **Herzlichen Glückwunsch zu deinem Erfolg!** Der Weg war vielleicht **nicht einfach**, aber jetzt hast du es **geschafft**!

- **Erfolg freigeschaltet:** \`🧩 | BADGE - MITGLIED\`
- Willkommen auf **diesem Server**. Hier findest du **Hilfe** zu deinen **Projekten** und kannst deine **Discord-Bots** gratis hosten.

<:Sterne:1303373321244639242> › Schalte **noch mehr** Erfolge frei, um eine **einzigartige** Rolle zu erhalten!`);

await member.send({embeds:[messageEmbed]});
    await member.send({embeds:[erfolgEmbed]});
    } catch (error) {
        console.error(`Konnte keine Nachricht an ${member.user.tag} senden:`, error);
    }

    const guild = member.guild;
    ROLE_IDS.forEach(async (roleId) => {
        const role = guild.roles.cache.get(roleId);
        if (role) {
            try {
                await member.roles.add(role);
            } catch (error) {
                console.error(`Konnte die Rolle ${role.name} nicht an ${member.user.tag} vergeben:`, error);
            }
        } else {
            console.error(`Rolle mit ID ${roleId} nicht gefunden.`);
        }
    });
});

client.on('messageCreate', async message => {
  if (message.author.bot) return;

  const data = JSON.parse(fs.readFileSync(countingDataPath, 'utf8'));
  const countingChannelId = data.channelId;
  let currentNumber = data.currentNumber || 0;
  let lastUserId = data.lastUserId || null;

  if (message.channel.id !== countingChannelId) return;

  const nextNumber = currentNumber + 1;

  if (/^\d+$/.test(message.content) && message.content === nextNumber.toString() && message.author.id !== lastUserId) {
      currentNumber++;
      lastUserId = message.author.id;
      fs.writeFileSync(countingDataPath, JSON.stringify({ channelId: countingChannelId, currentNumber, lastUserId }));
      await message.react('✅');
  } else if (/^\d+$/.test(message.content)) {
      currentNumber = 0;
      fs.writeFileSync(countingDataPath, JSON.stringify({ channelId: countingChannelId, currentNumber, lastUserId }));
      await message.react('❌');
      await message.channel.send('`❌`〢**Falsche Zahl oder dieselbe Person.** Das Spiel fängt bei **1** an.');
  }
});

const voiceXPMap = new Map();

client.on('messageCreate', async (message) => {
  if (message.author.bot) return;

  const userId = message.author.id;
  const channelId = message.channel.id;

  let userData = level.level.users.find(user => user.userid === userId);
  if (!userData) {
    userData = { userid: userId, xp: 0, level: 1, messages: 0, hideStats: false };
    level.level.users.push(userData);
  }

  if (level.level.blacklist && level.level.blacklist.includes(channelId)) {
    return;
  }

  userData.xp += 15;
  userData.messages += 1;

  const requiredXP = Math.ceil(baseXP * Math.pow(xpPerLevelMultiplier, userData.level - 1));

  while (userData.xp >= requiredXP) {
    userData.xp -= requiredXP;
    userData.level++;

    const levelRoles = level.level.levelRoles || [];
    const roleEntry = levelRoles.find(entry => entry.level === userData.level);
    if (roleEntry) {
      const role = message.guild.roles.cache.get(roleEntry.roleId);
      if (role) {
        const member = message.guild.members.cache.get(userId);
        if (member) {
          await member.roles.add(role).catch(err => console.error(`Fehler beim Hinzufügen der Rolle: ${err}`));
        }
      }
    }

    if (!userData.hideStats) {
      if (level.level.levelChannel) {
        const sendLevelChannel = message.guild.channels.cache.get(level.level.levelChannel);
        sendLevelChannel?.send({ content: `\`🔼\`〢<@${userId}>, du hast **Level ${userData.level}** erreicht!` }).catch(() => {
          message.reply({ content: `\`🔼\`〢<@${userId}>, du hast **Level ${userData.level}** erreicht!` });
        });
      } else {
        message.reply({ content: `\`🔼\`〢<@${userId}>, du hast **Level ${userData.level}** erreicht!` });
      }
    }
  }

  fs.writeFileSync(levelPath, JSON.stringify(level, null, 2), (err) => {
    if (err) {
      console.error('Fehler beim Schreiben der Daten:', err);
    }
  });
});

client.on('voiceStateUpdate', async (oldState, newState) => {
  if (newState.member.user.bot) return;

  const userId = newState.member.id;

  if (!newState.channelId && oldState.channelId) {
    clearInterval(voiceXPMap.get(userId)?.interval);
    voiceXPMap.delete(userId);
  } else if (newState.channelId && !oldState.channelId) {
    const interval = setInterval(() => {
      const userData = level.level.users.find(user => user.userid === userId);
      if (!userData) return;

      userData.xp += 3;

      const requiredXP = Math.ceil(baseXP * Math.pow(xpPerLevelMultiplier, userData.level - 1));

      while (userData.xp >= requiredXP) {
        userData.xp -= requiredXP;
        userData.level++;
      }

      }, 60000);

    voiceXPMap.set(userId, { interval });
  }
});

client.on('guildMemberUpdate', async (oldMember, newMember) => {
  const oldBoostCount = oldMember.premiumSince ? 1 : 0;
  const newBoostCount = newMember.premiumSince ? 1 : 0;

  if (newBoostCount > oldBoostCount) {
    const userId = newMember.id;

    let userData = level.level.users.find(user => user.userid === userId);
    if (!userData) {
      userData = { userid: userId, xp: 0, level: 1, messages: 0, hideStats: false };
      level.level.users.push(userData);
    }

    const additionalBoosts = newBoostCount - oldBoostCount;
    userData.xp += 200 * additionalBoosts;

    const requiredXP = Math.ceil(baseXP * Math.pow(xpPerLevelMultiplier, userData.level - 1));

    while (userData.xp >= requiredXP) {
      userData.xp -= requiredXP;
      userData.level++;
    }

    fs.writeFileSync(levelPath, JSON.stringify(level, null, 2));
  }
});

client.on('interactionCreate', async interaction => {
  if (!interaction.isSelectMenu()) return;

  const selectedValue = interaction.values[0];
  if (interaction.customId === 'einführungselect') {
    const logChannel = await interaction.guild.channels.cache.get("1298922351320236032");
    if (selectedValue === "vorteile_boost") {
    const messageEmbed = new EmbedBuilder()
          .setColor("#5865f2")
          .setDescription(`### <:Rackete:1303373302818930738> × BOOST VORTEILE
› **Danke** an jeden **Server Booster**! Mit jedem **Boost** helft ihr uns dabei, unseren **Server** auf das **nächste** Level zu bringen und **exklusive** Vorteile für die gesamte **Community** zu ermöglichen!

### <:Sterne:1303373321244639242>  - DEINE VORTEILE

- Die Rolle <@&1302670952798224425> *
- **Pro Boost** einen weiteren **Server Slot**. *
- **25.000$** im <#1298939809632620545> pro **Boost**.
- **Pro Boost** ein **custom Emoji** deiner Wahl, welches dem **Server** hinzugefügt wird.
- **150 XP** pro **Server Boost**.

**Beachte** das die mit einem * gekennzeichneten Belohnungen nur solange halten, wie auch der/die Boost aktiv sind`);

        await interaction.reply({ embeds: [messageEmbed], ephemeral: true });
    }

    if (selectedValue === "vorteile_invites") {
        const embed = new EmbedBuilder()
          .setColor("#5865f2")
          .setDescription(`### <:Schilder:1303373314986741800> × INVITE VORTEILE
› Wenn du andere Benutzer auf den Server einlädst, bekommst
du viele tolle Belohnungen von uns! Die Eingeladeten dürften keine alt-accs sein.

<@&1313126654356361298> 
- Alle Vorteile von Türsteher
- +1 zusätzliche Server Slots
- Kleiner Discord Bot von uns! (Ticketsystem + Level)
- +150MB RAM
- +600MB Speicher
- Eigenes Icon für die Rolle

<@&1313126657153961994> 
- Alle Vorteile von Schildträger
- Im Nächsten Video wirst du gegrüßt
- Eigene Rolle + Farbe
- +125MB RAM
- + 250MB Speicher

<@&1313126660173856790>
- +80MB RAM
- +250MB Speicher
- **Zugriff auf <#1313468806034886698>**

**WICHTIG**: __Ihr müsst euren eigenen Invite-Link erstellen!__ **Wenn ihr unten auf den Button "Invite Belohnungen einfordern" klickt, öffnet sich ein Ticket.**`);
         
         const inviteButton = new ButtonBuilder()
.setCustomId('inviteButton')
.setLabel(' - Invite Belohnungen einfordern')
.setEmoji('1303373340920119376')
.setStyle(ButtonStyle.Secondary);

const inviteRow = new ActionRowBuilder()
.addComponents(inviteButton);
        await interaction.reply({ embeds: [embed], components: [inviteRow], ephemeral: true });
    
    }
    if (selectedValue === "keine_botdms") {
      
    }
    if (selectedValue === "server_erfolge") {
          const messageEmbed = new EmbedBuilder()
          .setColor("#5865f2")
          .setDescription(`### <:Schilder:1303373314986741800> - SERVER ERFOLGE
› Hier **findest** du alle **Informationen** über die **Erfolge** dieses
Servers! **Sammle** alle für eine **Geheime Rolle**!

<@&1298794609672982591> 
> **Melde** einen **Bug** im <#1298951101223145472> 

<@&1298794848647778415> 
> Sei **1 Jahr lang** Teil unserer **Community**!

<@&1298795497154150400> 
> Wird beim **Beitritt** direkt **zugewiesen**.

<@&1298795667887493140> 
> **Erreiche** das **maximale Level** auf diesem Server.

<@&1298940456830369873> 
> Hole dir **deinen eigenen** gratis **Server**.

\`@GEHEIME ROLLE\`
> **Sammle alle Erfolge**, für eine **geheime** spizielle Rolle.`);

        await interaction.reply({ embeds: [messageEmbed], ephemeral: true });
    }
       if (selectedValue === "server_spezialrollen") {
          const messageEmbed = new EmbedBuilder()
          .setColor("#5865f2")
          .setDescription(`### <:Discordrole:1302714885104336896> - SPECIAL ROLLEN
› Hier **findest** du alle **Informationen** über die **Special Rollen** dieses
Servers!

<@&1298798182247174244> 
> Nur zu **Weihnachten** in einem Event **erhältlich**.

<@&1298798848306839623> 
> Nur zu **Halloween** in einem Event **erhältlich**.

<@&1298799044818108418> 
> Nur zu **Ostern** in einem Event **erhältlich**.

<@&1298795040788713472> 
> **Alte Teammitglieder** bekommen diese **Rolle**.

<@&1298778067484807201> 
> Durch **Gewinnspiele** erhältlich.

<@&1298777470668902420> 
> **Enge Freunde** von **EinfxchPingu**.

<@&1298777624495259710> 
> Erstelle **Videos** auf **Plattformen** wie **Youtube oder streame**.

<@&1298777805865353389> 
> **Partnere** mit unserem **Server**.

<@&1298795160338960384>
> **Spendiere** ein Gewinnspiel oder **trage** etwas zum Server **bei**

<@&1302670952798224425> 
> Unsere **lieben Server Booster** 💕`);

        await interaction.reply({ embeds: [messageEmbed], ephemeral: true });
    }
    if (selectedValue === "server_levelrollen") {
               const messageEmbed = new EmbedBuilder()
          .setColor("#5865f2")
          .setDescription(`### <:Sterne:1303373321244639242> × ALLE LEVEL ROLLEN
› Hier **findest** du alle **Informationen** über die **Level Rollen** dieses
Servers!

<@&1298784669407641610> 
> › Verwende **Fremde Emojis** und bette **Links** ein.

<@&1298784851872448623> 
> › Ändere deinen **Nickname**
> › **Schreibrechte** in <#1317415724364333117>

<@&1298785027554938972> 
> › Erstelle **Umfragen** in **öffentlichen Chats**

<@&1298785185617149962> 
> › Du musst **keine Vorraussetzungen** mehr für **Gewinnspiele** erfüllen.

<@&1298785394753536021> 
> › Deine **eigene Rolle** + **Farbe**!

<@&1298786296822497390> 
> › **Eigenes Icon** für deine **Rolle**.

<@&1298785809658282085> 
> › Erstelle ein **eigenes Server-Emote** für **alle Mitglieder**!`);

        await interaction.reply({ embeds: [messageEmbed], ephemeral: true });
    }
    if (selectedValue === "hosting4free") {
     
    }
    if (selectedValue === "youtube_kanal") {
        await interaction.reply({content:`\`📹\`〢Auf meinem [**Youtube Kanal**](https://www.youtube.com/@EinfxchPingu) findest du **viele Tutorials** und andere **Videos**. **Abonniere** meinen **Kanal** doch gerne. Es ist **kostenlos** und ein **sehr einfacher Schritt**, aber er **bedeutet** mir **sehr viel**!`,ephemeral: true});
    }
  }
});

//snowvemberselect

client.on('interactionCreate', async interaction => {
  if (!interaction.isSelectMenu()) return;

  const selectedValue = interaction.values[0];
  if (interaction.customId === 'snowvemberselect') {
    const logChannel = await interaction.guild.channels.cache.get("1298922351320236032");
    let modal;
    if (selectedValue === "speicher") {
    
          modal = new ModalBuilder()
              .setCustomId('speicherModal')
              .setTitle('🎒 × +500MB Speicher');
          
          const speicherinput = new TextInputBuilder()
              .setCustomId('speicherinput')
              .setLabel("🆔 - Deine Server-ID")
              .setStyle(TextInputStyle.Short)
              .setPlaceholder("Die ID deines Bot-Servers")
              .setRequired(true);
  
          modal.addComponents(
              new ActionRowBuilder().addComponents(speicherinput)
          );
          await interaction.showModal(modal);
    }

    if (selectedValue === "ram") {
    
      modal = new ModalBuilder()
          .setCustomId('ramModal')
          .setTitle('➕ × +85MB Ram');
      
      const ramInput = new TextInputBuilder()
          .setCustomId('ramInput')
          .setLabel("🆔 - Deine Server-ID")
          .setStyle(TextInputStyle.Short)
          .setPlaceholder("Die ID deines Bot-Servers")
          .setRequired(true);

      modal.addComponents(
          new ActionRowBuilder().addComponents(ramInput)
      );
      await interaction.showModal(modal);
    }
    if (selectedValue === "event_rolle") {
      let userData = snowvember.users.find(user => user.userid === interaction.user.id);
      let itemData = snowvember.items.find(item => item.itemname === selectedValue);
      if (interaction.member.roles.cache.has("1298798182247174244")) {
        return interaction.reply({content:"`❌`〢Du **hast** die **<@&1298798182247174244> Rolle** bereits!", ephemeral: true});
      }
      if (itemData.storage >= 0) {
        
        if (userData.zuckerstangen >= 650) {
          userData.zuckerstangen -= 650;

          interaction.member.roles.add("1298798182247174244");
            itemData.storage -= 1;
          interaction.reply({ content: "`✅`〢Du hast **erfolgreich** die **<@&1298798182247174244> Rolle** gekauft!", ephemeral: true });
          fs.writeFileSync(snowvemberPath, JSON.stringify(snowvember, null, 2));
        } else {
          interaction.reply({ content: "`❌`〢Du hast **nicht** genug **Zuckerstangen**!", ephemeral: true });
        }
      } else {
        interaction.reply({ content: "`❌`〢Diese **Belohnung** ist **ausverkauft**. Deshalb **kannst** du sie **nicht kaufen**!", ephemeral: true });
      }
    }
    if (selectedValue === "server_slot") {
      modal = new ModalBuilder()
          .setCustomId('serverslotModal')
          .setTitle('💻 × Zusätzlichen Server Slot');
      
      const emailInput = new TextInputBuilder()
          .setCustomId('emailInput')
          .setLabel("👤 - Deine Email Adresse")
          .setStyle(TextInputStyle.Short)
          .setPlaceholder("Die Email Addresse deines Kontos")
          .setRequired(true);

      modal.addComponents(
          new ActionRowBuilder().addComponents(emailInput)
      );
      await interaction.showModal(modal);
    }
    if (selectedValue === "nitro") {
      let userData = snowvember.users.find(user => user.userid === interaction.user.id);
      let itemData = snowvember.items.find(item => item.itemname === selectedValue);
      if (itemData.storage >= 0) {
        
        if (userData.zuckerstangen >= 1500) {
          userData.zuckerstangen -= 1500;
            itemData.storage -= 1;
          try {
            const channel = await interaction.guild.channels.create({
              name: `⛄〢${interaction.user.username}`,
              type: ChannelType.GuildText,
              parent: '1299865222487474207',
              permissionOverwrites: [
                {
                  id: interaction.guild.id,
                  deny: [PermissionsBitField.Flags.ViewChannel],
                },
                {
                  id: interaction.user.id,
                  allow: [PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ViewChannel],
                },
                {
                  id: '1298918662199312385',
                  allow: [PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ViewChannel],
                },
              ],
            });
          
            const ticketEmbed = new EmbedBuilder()
              .setThumbnail(interaction.user.displayAvatarURL())
              .setDescription(`### <:Ticket:1303373350730596452> × WILLKOMMEN IM TICKET
          › Bitte habe einen **kleinen Moment** gedult. Dir wird **so schnell wie möglich** ein Teammitglied **helfen**.
            
          ### <:Datei:1303373300554272789> - ANGEGEBENE DETAILS
          
          › **Ticket Grund**
        \`Snovember Event Nitro einforderung\``)
              .setColor('#5865f2');
          
              const closeButton = new ButtonBuilder()
              .setCustomId('close')
              .setLabel(' - Ticket schließen')
              .setEmoji('1303388353965592626')
              .setStyle(ButtonStyle.Secondary);
          
              const claimButton = new ButtonBuilder()
              .setCustomId('claim')
              .setLabel(' - Ticket beanspruchen')
              .setEmoji('1303388351822434335')
              .setStyle(ButtonStyle.Secondary);
          
            const embedRow = new ActionRowBuilder()
              .addComponents(closeButton, claimButton);
          
            await channel.send({ embeds: [ticketEmbed], components: [embedRow] });
          
            const logEmbed2 = new EmbedBuilder()
              .setDescription(`### <:Ticket:1303373350730596452> × TICKET WURDE GEÖFFNET
          - Ticket-ID: \`#${interaction.channel.id}\`
          - Ticket Panel: \`Snovember Event Nitro einforderung\`
          - Ticket erstellt von: <@${interaction.user.id}> *(${interaction.user.tag})*
          - Datum und Uhrzeit: \`${formatDateInBerlinTimezone(new Date())}\``)
              .setColor('#5865f2');
          
          
            const sentLogEmbed2 = await logChannel.send({ embeds: [logEmbed2] });
          
            const newTicket = {
              ticketId: channel.id,
              userid: interaction.user.id,
              usertag: interaction.user.tag,
              ticketpanel: "Snovember Event Nitro einforderung",
              logEmbed2Id: sentLogEmbed2.id,
              claimed: false
            };
          
            tickets.tickets.push(newTicket);
            fs.writeFileSync(ticketPath, JSON.stringify(tickets, null, 2));
          
              await interaction.reply({ content: `\`✅\`〢Deine **Belohnung** kannst du in **diesem Ticket** einfordern: <#${channel.id}>`, ephemeral: true });
            
          } catch (error) {
              await interaction.reply({ content: '`❌`〢Es ist ein **Fehler** aufgetreten! Bitte melde **folgendes** einem Administrator:``` ' + error + "```", ephemeral: true });
            
          }
          fs.writeFileSync(snowvemberPath, JSON.stringify(snowvember, null, 2));
        } else {
          interaction.reply({ content: "`❌`〢Du hast **nicht** genug **Zuckerstangen**!", ephemeral: true });
        }
      } else {
        interaction.reply({ content: "`❌`〢Diese **Belohnung** ist **ausverkauft**. Deshalb **kannst** du sie **nicht kaufen**!", ephemeral: true });
      }
    }
  }
});

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isModalSubmit()) return;

  const modalId = interaction.customId;
  const logChannel = await interaction.guild.channels.cache.get("1298922167244816394");
try {
  if (modalId === 'speicherModal') {
    let userData = snowvember.users.find(user => user.userid === interaction.user.id);
    let itemData = snowvember.items.find(item => item.itemname === "speicher");
    const serverid = interaction.fields.getTextInputValue('speicherinput');
    if (!userData) {
      userData = { userid: interaction.user.id, zuckerstangen: 0 };
      snowvember.users.push(userData);
    }
    if (itemData.storage >= 0) {
      
      if (userData.zuckerstangen >= 200) {
        userData.zuckerstangen -= 200;
itemData.storage -= 1;

        
        interaction.reply({ content: "`⛄`〢Du hast **erfolgreich** diese Belohnung **gekauft**! **Es kann bis zu 2 Stunden dauern, bis dir dein Speicher zugewiesen wird!**.", ephemeral: true });
        const logEmbed2 = new EmbedBuilder()
          .setDescription(`### <:christmas_tree:1299810501504536707> × EVENT BELOHNUNGS EINFORDERUNG (+500MB Speicher)
  - Server-ID: \`${serverid}\`
  - Eingefordert von: <@${interaction.user.id}> *(${interaction.user.tag})*
  - Datum und Uhrzeit: \`${formatDateInBerlinTimezone(new Date())}\``)
          .setColor('#5865f2');
  
  
        await logChannel.send({ content:"<@&1298918662199312385>", embeds: [logEmbed2] });
        fs.writeFileSync(snowvemberPath, JSON.stringify(snowvember, null, 2));
      } else {
        interaction.reply({ content: "`❌`〢Du hast **nicht** genug **Zuckerstangen**!", ephemeral: true });
      }
    } else {
      interaction.reply({ content: "`❌`〢Diese **Belohnung** ist **ausverkauft**. Deshalb **kannst** du sie **nicht kaufen**!", ephemeral: true });
    }
  }

  if (modalId === 'serverslotModal') {
    let userData = snowvember.users.find(user => user.userid === interaction.user.id);
    let itemData = snowvember.items.find(item => item.itemname === "server_slot");
    const serverid = interaction.fields.getTextInputValue('emailInput');
    if (!userData) {
      userData = { userid: interaction.user.id, zuckerstangen: 0 };
      snowvember.users.push(userData);
    }
    if (itemData.storage >= 0) {
    
      if (userData.zuckerstangen >= 950) {
        userData.zuckerstangen -= 950;

          itemData.storage -= 1;

        
        interaction.reply({ content: "`⛄`〢Du hast **erfolgreich** diese Belohnung **gekauft**! **Es kann bis zu 2 Stunden dauern, bis dir dein Server Slot zugewiesen wird!**.", ephemeral: true });
        const logEmbed2 = new EmbedBuilder()
          .setDescription(`### <:christmas_tree:1299810501504536707> × EVENT BELOHNUNGS EINFORDERUNG (Server Slot)
  - Email Adresse: \`${serverid}\`
  - Eingefordert von: <@${interaction.user.id}> *(${interaction.user.tag})*
  - Datum und Uhrzeit: \`${formatDateInBerlinTimezone(new Date())}\``)
          .setColor('#5865f2');
  
  
            
            
          await logChannel.send({ content:"<@&1298918662199312385>", embeds: [logEmbed2] });
        fs.writeFileSync(snowvemberPath, JSON.stringify(snowvember, null, 2));
      } else {
        interaction.reply({ content: "`❌`〢Du hast **nicht** genug **Zuckerstangen**!", ephemeral: true });
      }
    } else {
      interaction.reply({ content: "`❌`〢Diese **Belohnung** ist **ausverkauft**. Deshalb **kannst** du sie **nicht kaufen**!", ephemeral: true });
    }
  }
  if(modalId === 'ramModal') {
    let userData = snowvember.users.find(user => user.userid === interaction.user.id);
    let itemData = snowvember.items.find(item => item.itemname === "ram");
    const serverid = interaction.fields.getTextInputValue('ramInput');
    if (!userData) {
      userData = { userid: interaction.user.id, zuckerstangen: 0 };
      snowvember.users.push(userData);
    }
    if (itemData.storage >= 0) {
      
      if (userData.zuckerstangen >= 200) {
        userData.zuckerstangen -= 200;
          itemData.storage -= 1;


        
        interaction.reply({ content: "`⛄`〢Du hast **erfolgreich** diese Belohnung **gekauft**! **Es kann bis zu 2 Stunden dauern, bis dir dein Ram zugewiesen wird!**.", ephemeral: true });
        const logEmbed2 = new EmbedBuilder()
          .setDescription(`### <:christmas_tree:1299810501504536707> × EVENT BELOHNUNGS EINFORDERUNG (+85MB RAM)
  - Server-ID: \`${serverid}\`
  - Eingefordert von: <@${interaction.user.id}> *(${interaction.user.tag})*
  - Datum und Uhrzeit: \`${formatDateInBerlinTimezone(new Date())}\``)
          .setColor('#5865f2');
  
  
            
            
          await logChannel.send({ content:"<@&1298918662199312385>", embeds: [logEmbed2] });
        fs.writeFileSync(snowvemberPath, JSON.stringify(snowvember, null, 2));
      } else {
        interaction.reply({ content: "`❌`〢Du hast **nicht** genug **Zuckerstangen**!", ephemeral: true });
      }
    } else {
      interaction.reply({ content: "`❌`〢Diese **Belohnung** ist **ausverkauft**. Deshalb **kannst** du sie **nicht kaufen**!", ephemeral: true });
    }
  }
} catch (error) {
  console.log(error);
}
});

client.on('interactionCreate', async interaction => {
  if (!interaction.isSelectMenu()) return;

  const selectedValue = interaction.values[0];

  if (selectedValue === 'cancel') {
    await interaction.deferUpdate();
    return;
  }
try {
    if (['support', 'bewerben', "melden", "hostingproblem"].includes(selectedValue)) {
      const logChannel = await interaction.guild.channels.cache.get("1298922351320236032");
      const username = interaction.user.username;
      
      let channelName = `${interaction.user.username}`;
      let modal;
    
      if (selectedValue === 'support') {
          channelName = `📌〢${interaction.user.username}`;
          modal = new ModalBuilder()
              .setCustomId('supportModal')
              .setTitle('📌 - Allgemeiner Support');
          
          const problemBeschreibung = new TextInputBuilder()
              .setCustomId('supportinputeins')
              .setLabel("💬 - Beschreibe dein Problem")
              .setStyle(TextInputStyle.Paragraph)
              .setPlaceholder("Beschreibe das Problem detailliert...")
              .setRequired(true);
  
          modal.addComponents(
              new ActionRowBuilder().addComponents(problemBeschreibung)
          );
      }
      
      if (selectedValue === 'bewerben') {
          channelName = `💼〢${interaction.user.username}`;
          modal = new ModalBuilder()
              .setCustomId('bewerbenModal')
              .setTitle('💼 - Team Bewerbung');
          
          const bewerbungsGrund = new TextInputBuilder()
              .setCustomId('bewerbunginput')
              .setLabel("💬 - Was möchtest du bewirken / Vorschläge")
              .setStyle(TextInputStyle.Short)
              .setMinLength(50)
              .setPlaceholder("Deine Ziele hier und vielleicht hast du noch Verbesserungsvorschläge")
              .setRequired(true);
  
          const erfahrungen = new TextInputBuilder()
              .setCustomId('bewerbunginputzwei')
              .setLabel("📚 - Welche Stärken und Schwächen hast du?")
              .setStyle(TextInputStyle.Paragraph)
              .setMinLength(125)
              .setPlaceholder("Erwähne relevante Erfahrungen")
              .setRequired(true);
          
          const steckbrief = new TextInputBuilder()
              .setCustomId('bewerbunginputdrei')
              .setLabel("👥 - Erzähle einbisschen was über dich")
              .setStyle(TextInputStyle.Paragraph)
              .setPlaceholder("Mein Name ist..")
              .setMinLength(50)
              .setRequired(true);
  
          modal.addComponents(
              new ActionRowBuilder().addComponents(steckbrief),
              new ActionRowBuilder().addComponents(erfahrungen),
              new ActionRowBuilder().addComponents(bewerbungsGrund)
          );
      }

  
      if (selectedValue === 'melden') {
          channelName = `🚨〢${interaction.user.username}`;
          modal = new ModalBuilder()
              .setCustomId('meldenModal')
              .setTitle('🚨 - Einen Benutzer/Fehler melden');
          
          const problemBeschreibung = new TextInputBuilder()
              .setCustomId('meldunginput')
              .setLabel("💬 - Beschreibe das Problem")
              .setStyle(TextInputStyle.Paragraph)
              .setPlaceholder("Details zum Problem")
              .setRequired(true);
  
          const userInvolviert = new TextInputBuilder()
              .setCustomId('meldunginputzwei')
              .setLabel("👤 - Welche Nutzer sind involviert?")
              .setStyle(TextInputStyle.Short)
              .setPlaceholder("Gib betroffene Nutzer an mit ID (Leer lassen wenn nicht)")
              .setRequired(false);
  
          modal.addComponents(
              new ActionRowBuilder().addComponents(problemBeschreibung),
              new ActionRowBuilder().addComponents(userInvolviert)
          );
      }

      if (selectedValue === 'hosting') {
        modal = new ModalBuilder()
            .setCustomId('hostingModal')
            .setTitle('🚀 - Server Hosting');
        
        const hostingSprache = new TextInputBuilder()
            .setCustomId('hostingSprache')
            .setLabel("💬 - Welche Programmiersprache?")
            .setStyle(TextInputStyle.Short)
            .setPlaceholder("Java, Javascript, Python")
            .setRequired(true);

        const hostingGrund = new TextInputBuilder()
            .setCustomId('hostingGrund')
            .setLabel("👤 - Benutzername")
            .setStyle(TextInputStyle.Short)
            .setPlaceholder("Wie sollst du heißen?")
            .setRequired(true);
          
 const hostingEmail = new TextInputBuilder()
            .setCustomId('hostingemail')
            .setLabel("📫 - Email Adresse")
            .setStyle(TextInputStyle.Short)
            .setPlaceholder("Deine Email Adresse")
            .setRequired(true);

        modal.addComponents(
            new ActionRowBuilder().addComponents(hostingSprache),
            new ActionRowBuilder().addComponents(hostingGrund),
            new ActionRowBuilder().addComponents(hostingEmail)
        );
    }
  
      if (selectedValue === 'hostingproblem') {
          channelName = `⚙️〢${interaction.user.username}`;
          modal = new ModalBuilder()
              .setCustomId('hostingProblemModal')
              .setTitle('⚙️ - Problem mit dem Hosting');
          
          const problemBeschreibung = new TextInputBuilder()
              .setCustomId('hostingProbleminput')
              .setLabel("💬 - Beschreibe dein Problem")
              .setStyle(TextInputStyle.Paragraph)
              .setPlaceholder("Beschreibe das Hosting-Problem...")
              .setRequired(true);
  
          const serverID = new TextInputBuilder()
              .setCustomId('hostingProbleminputzwei')
              .setLabel("🆔 - Server-ID")
              .setStyle(TextInputStyle.Short)
              .setPlaceholder("Server-ID eingeben (Leer lassen wenn nicht)")
              .setRequired(false);
  
          modal.addComponents(
              new ActionRowBuilder().addComponents(problemBeschreibung),
              new ActionRowBuilder().addComponents(serverID)
          );
      
        }
      
        await interaction.showModal(modal);
    }
    if (selectedValue === 'gewinn') {
      try {
        const logChannel = await interaction.guild.channels.cache.get("1298922351320236032");
        const channel = await interaction.guild.channels.create({
          name: `🎉〢${interaction.user.username}`,
          type: ChannelType.GuildText,
          parent: '1299865222487474207',
          permissionOverwrites: [
            {
              id: interaction.guild.id,
              deny: [PermissionsBitField.Flags.ViewChannel],
            },
            {
              id: interaction.user.id,
              allow: [PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ViewChannel],
            },
            {
              id: '1298918662199312385',
              allow: [PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ViewChannel],
            },
          ],
        });
  
        const ticketEmbed = new EmbedBuilder()
          .setThumbnail(interaction.user.displayAvatarURL())
          .setDescription(`### <:Ticket:1303373350730596452> × WILLKOMMEN IM TICKET
  › Bitte habe einen **kleinen Moment** gedult. Dir wird **so schnell wie möglich** ein Teammitglied **helfen**.
  
  ### <:Datei:1303373300554272789> - ANGEGEBENE DETAILS
  
  › *Keine Details*`)
          .setColor('#5865f2');
  
        const closeButton = new ButtonBuilder()
          .setCustomId('close')
          .setLabel(' - Ticket schließen')
          .setEmoji('1303388353965592626')
          .setStyle(ButtonStyle.Secondary);
  
          const claimButton = new ButtonBuilder()
          .setCustomId('claim')
          .setLabel(' - Ticket beanspruchen')
          .setEmoji('1303388351822434335')
          .setStyle(ButtonStyle.Secondary);
  
        const embedRow = new ActionRowBuilder()
          .addComponents(closeButton, claimButton);
  
        await channel.send({ embeds: [ticketEmbed], components: [embedRow] });
  
        const logEmbed2 = new EmbedBuilder()
          .setDescription(`### <:Ticket:1303373350730596452> × TICKET WURDE GEÖFFNET
  - Ticket-ID: \`#${interaction.channel.id}\`
  - Ticket Panel: \`Gewinn beanspruchen\`
  - Ticket erstellt von: <@${interaction.user.id}> *(${interaction.user.tag})*
  - Datum und Uhrzeit: \`${formatDateInBerlinTimezone(new Date())}\``)
          .setColor('#5865f2');
  
  
        const sentLogEmbed2 = await logChannel.send({ embeds: [logEmbed2] });
  
        const newTicket = {
          ticketId: channel.id,
          userid: interaction.user.id,
          usertag: interaction.user.tag,
          ticketpanel: "Gewinn beanspruchen",
          logEmbed2Id: sentLogEmbed2.id,
          claimed: false
        };
  
        tickets.tickets.push(newTicket);
        fs.writeFileSync(ticketPath, JSON.stringify(tickets, null, 2));
  
          await interaction.reply({ content: `\`✅\`〢Dein **Ticket** wurde hier **erstellt**: <#${channel.id}>`, ephemeral: true });
        
      } catch (error) {
          await interaction.reply({ content: '`❌`〢Es ist ein **Fehler** aufgetreten! Bitte melde **folgendes** einem Administrator:``` ' + error + "```", ephemeral: true });
        
      }
    }
  } catch (error) {
    console.log(error);
  }
 
});



client.on('interactionCreate', async (interaction) => {
  if (!interaction.isModalSubmit()) return;

  const modalId = interaction.customId;
  const logChannel = await interaction.guild.channels.cache.get("1298922351320236032");

  if (modalId === 'supportModal') {

        const username = interaction.user.username;
        problemBeschreibung = interaction.fields.getTextInputValue('supportinputeins');
        
    try {
      const channel = await interaction.guild.channels.create({
        name: `📌〢${interaction.user.username}`,
        type: ChannelType.GuildText,
        parent: '1299865222487474207',
        permissionOverwrites: [
          {
            id: interaction.guild.id,
            deny: [PermissionsBitField.Flags.ViewChannel],
          },
          {
            id: interaction.user.id,
            allow: [PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ViewChannel],
          },
          {
            id: '1298918662199312385',
            allow: [PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ViewChannel],
          },
        ],
      });

      const ticketEmbed = new EmbedBuilder()
        .setThumbnail(interaction.user.displayAvatarURL())
        .setDescription(`### <:Ticket:1303373350730596452> × WILLKOMMEN IM TICKET
› Bitte habe einen **kleinen Moment** gedult. Dir wird **so schnell wie möglich** ein Teammitglied **helfen**.
  
### <:Datei:1303373300554272789> - ANGEGEBENE DETAILS

› **Beschreibe dein Problem**
\`${problemBeschreibung}\`
`)
        .setColor('#5865f2');

        const closeButton = new ButtonBuilder()
          .setCustomId('close')
          .setLabel(' - Ticket schließen')
          .setEmoji('1303388353965592626')
          .setStyle(ButtonStyle.Secondary);
  
          const claimButton = new ButtonBuilder()
          .setCustomId('claim')
          .setLabel(' - Ticket beanspruchen')
          .setEmoji('1303388351822434335')
          .setStyle(ButtonStyle.Secondary);
  
        const embedRow = new ActionRowBuilder()
          .addComponents(closeButton, claimButton);
  
        await channel.send({ embeds: [ticketEmbed], components: [embedRow] });
  
        const logEmbed2 = new EmbedBuilder()
          .setDescription(`### <:Ticket:1303373350730596452> × TICKET WURDE GEÖFFNET
- Ticket-ID: \`#${interaction.channel.id}\`
- Ticket Panel: \`Allgemeiner Support\`
- Ticket erstellt von: <@${interaction.user.id}> *(${interaction.user.tag})*
- Datum und Uhrzeit: \`${formatDateInBerlinTimezone(new Date())}\``)
        .setColor('#5865f2');


      const sentLogEmbed2 = await logChannel.send({ embeds: [logEmbed2] });

      const newTicket = {
        ticketId: channel.id,
        userid: interaction.user.id,
        usertag: interaction.user.tag,
        ticketpanel: "Allgemeiner Support",
        logEmbed2Id: sentLogEmbed2.id,
        claimed: false
      };

      tickets.tickets.push(newTicket);
      fs.writeFileSync(ticketPath, JSON.stringify(tickets, null, 2));

        await interaction.reply({ content: `\`✅\`〢Dein **Ticket** wurde hier **erstellt**: <#${channel.id}>`, ephemeral: true });
      
    } catch (error) {
        await interaction.reply({ content: '`❌`〢Es ist ein **Fehler** aufgetreten! Bitte melde **folgendes** einem Administrator:``` ' + error + "```", ephemeral: true });
      
    }
  }
  
  if (modalId === 'bewerbenModal') {
    const username = interaction.user.username;
    bewerbungsGrund = interaction.fields.getTextInputValue('bewerbunginput');
    erfahrungen = interaction.fields.getTextInputValue('bewerbunginputzwei') || '/';
    steckbrief = interaction.fields.getTextInputValue('bewerbunginputdrei') || '/';
   
    
try {
  const channel = await interaction.guild.channels.create({
    name: `💼〢${interaction.user.username}`,
    type: ChannelType.GuildText,
    parent: '1299865222487474207',
    permissionOverwrites: [
      {
        id: interaction.guild.id,
        deny: [PermissionsBitField.Flags.ViewChannel],
      },
      {
        id: interaction.user.id,
        allow: [PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ViewChannel],
      },
      {
        id: '1298918662199312385',
        allow: [PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ViewChannel],
      },
    ],
  });

  const ticketEmbed = new EmbedBuilder()
    .setThumbnail(interaction.user.displayAvatarURL())
    .setDescription(`### <:Ticket:1303373350730596452> × WILLKOMMEN IM TICKET
› Bitte habe einen **kleinen Moment** gedult. Dir wird **so schnell wie möglich** ein Teammitglied **helfen**.
  
### <:Datei:1303373300554272789> - ANGEGEBENE DETAILS

› **Erzähle einbisschen was über dich**
\`${steckbrief}\`

› **Welche Stärken und Schwächen hast du?**
\`${erfahrungen}\`

› **Was möchtest du bewirken / Verbesserungsvorschläge**
\`${bewerbungsGrund}\`
`)
    .setColor('#5865f2');

    const closeButton = new ButtonBuilder()
    .setCustomId('close')
    .setLabel(' - Ticket schließen')
    .setEmoji('1303388353965592626')
    .setStyle(ButtonStyle.Secondary);

    const claimButton = new ButtonBuilder()
    .setCustomId('claim')
    .setLabel(' - Ticket beanspruchen')
    .setEmoji('1303388351822434335')
    .setStyle(ButtonStyle.Secondary);

  const embedRow = new ActionRowBuilder()
    .addComponents(closeButton, claimButton);

  await channel.send({ embeds: [ticketEmbed], components: [embedRow] });

  const logEmbed2 = new EmbedBuilder()
    .setDescription(`### <:Ticket:1303373350730596452> × TICKET WURDE GEÖFFNET
- Ticket-ID: \`#${interaction.channel.id}\`
- Ticket Panel: \`Team Bewerbung\`
- Ticket erstellt von: <@${interaction.user.id}> *(${interaction.user.tag})*
- Datum und Uhrzeit: \`${formatDateInBerlinTimezone(new Date())}\``)
    .setColor('#5865f2');


  const sentLogEmbed2 = await logChannel.send({ embeds: [logEmbed2] });

  const newTicket = {
    ticketId: channel.id,
    userid: interaction.user.id,
    usertag: interaction.user.tag,
    ticketpanel: "Team Bewerbung",
    logEmbed2Id: sentLogEmbed2.id,
    claimed: false
  };

  tickets.tickets.push(newTicket);
  fs.writeFileSync(ticketPath, JSON.stringify(tickets, null, 2));

    await interaction.reply({ content: `\`✅\`〢Dein **Ticket** wurde hier **erstellt**: <#${channel.id}>`, ephemeral: true });
  
} catch (error) {
    await interaction.reply({ content: '`❌`〢Es ist ein **Fehler** aufgetreten! Bitte melde **folgendes** einem Administrator:``` ' + error + "```", ephemeral: true });
  
}
  }

  
  if (modalId === 'meldenModal') {
    problemBeschreibung = interaction.fields.getTextInputValue('meldunginput');
    userInvolviert = interaction.fields.getTextInputValue('meldunginputzwei') || '/';
   
    
try {
  const channel = await interaction.guild.channels.create({
    name: `🚨〢${interaction.user.username}`,
    type: ChannelType.GuildText,
    parent: '1299865222487474207',
    permissionOverwrites: [
      {
        id: interaction.guild.id,
        deny: [PermissionsBitField.Flags.ViewChannel],
      },
      {
        id: interaction.user.id,
        allow: [PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ViewChannel],
      },
      {
        id: '1298918662199312385',
        allow: [PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ViewChannel],
      },
    ],
  });

  const ticketEmbed = new EmbedBuilder()
    .setThumbnail(interaction.user.displayAvatarURL())
    .setDescription(`### <:Ticket:1303373350730596452> × WILLKOMMEN IM TICKET
› Bitte habe einen **kleinen Moment** gedult. Dir wird **so schnell wie möglich** ein Teammitglied **helfen**.
  
### <:Datei:1303373300554272789> - ANGEGEBENE DETAILS

› **Beschreibe das Problem**
\`${problemBeschreibung}\`

› **Welche Nutzer sind involviert?**
\`${userInvolviert}\`
`)
    .setColor('#5865f2');

    const closeButton = new ButtonBuilder()
    .setCustomId('close')
    .setLabel(' - Ticket schließen')
    .setEmoji('1303388353965592626')
    .setStyle(ButtonStyle.Secondary);

    const claimButton = new ButtonBuilder()
    .setCustomId('claim')
    .setLabel(' - Ticket beanspruchen')
    .setEmoji('1303388351822434335')
    .setStyle(ButtonStyle.Secondary);

  const embedRow = new ActionRowBuilder()
    .addComponents(closeButton, claimButton);

  await channel.send({ embeds: [ticketEmbed], components: [embedRow] });

  const logEmbed2 = new EmbedBuilder()
    .setDescription(`### <:Ticket:1303373350730596452> × TICKET WURDE GEÖFFNET
- Ticket-ID: \`#${interaction.channel.id}\`
- Ticket Panel: \`Benutzer/Fehler Meldung\`
- Ticket erstellt von: <@${interaction.user.id}> *(${interaction.user.tag})*
- Datum und Uhrzeit: \`${formatDateInBerlinTimezone(new Date())}\``)
    .setColor('#5865f2');


  const sentLogEmbed2 = await logChannel.send({ embeds: [logEmbed2] });

  const newTicket = {
    ticketId: channel.id,
    userid: interaction.user.id,
    usertag: interaction.user.tag,
    ticketpanel: "Benutzer/Fehler Meldung",
    logEmbed2Id: sentLogEmbed2.id,
    claimed: false
  };

  tickets.tickets.push(newTicket);
  fs.writeFileSync(ticketPath, JSON.stringify(tickets, null, 2));

    await interaction.reply({ content: `\`✅\`〢Dein **Ticket** wurde hier **erstellt**: <#${channel.id}>`, ephemeral: true });
  
} catch (error) {
    await interaction.reply({ content: '`❌`〢Es ist ein **Fehler** aufgetreten! Bitte melde **folgendes** einem Administrator:``` ' + error + "```", ephemeral: true });
  
}
  }
  
  if (modalId === 'hostingProblemModal') {
    problemBeschreibung = interaction.fields.getTextInputValue('hostingProbleminput');
    serverID = interaction.fields.getTextInputValue('hostingProbleminputzwei') || '/';
   
    
try {
  const channel = await interaction.guild.channels.create({
    name: `⚙️〢${interaction.user.username}`,
    type: ChannelType.GuildText,
    parent: '1299865222487474207',
    permissionOverwrites: [
      {
        id: interaction.guild.id,
        deny: [PermissionsBitField.Flags.ViewChannel],
      },
      {
        id: interaction.user.id,
        allow: [PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ViewChannel],
      },
      {
        id: '1298918662199312385',
        allow: [PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ViewChannel],
      },
    ],
  });

  const ticketEmbed = new EmbedBuilder()
    .setThumbnail(interaction.user.displayAvatarURL())
    .setDescription(`### <:Ticket:1303373350730596452> × WILLKOMMEN IM TICKET
› Bitte habe einen **kleinen Moment** gedult. Dir wird **so schnell wie möglich** ein Teammitglied **helfen**.
  
### <:Datei:1303373300554272789> - ANGEGEBENE DETAILS

› **Beschreibe dein Problem**
\`${problemBeschreibung}\`

› **Server-ID**
\`${serverID}\`
`)
    .setColor('#5865f2');

    const closeButton = new ButtonBuilder()
    .setCustomId('close')
    .setLabel(' - Ticket schließen')
    .setEmoji('1303388353965592626')
    .setStyle(ButtonStyle.Secondary);

    const claimButton = new ButtonBuilder()
    .setCustomId('claim')
    .setLabel(' - Ticket beanspruchen')
    .setEmoji('1303388351822434335')
    .setStyle(ButtonStyle.Secondary);

  const embedRow = new ActionRowBuilder()
    .addComponents(closeButton, claimButton);

  await channel.send({ embeds: [ticketEmbed], components: [embedRow] });

  const logEmbed2 = new EmbedBuilder()
    .setDescription(`### <:Ticket:1303373350730596452> × TICKET WURDE GEÖFFNET
- Ticket-ID: \`#${interaction.channel.id}\`
- Ticket Panel: \`Hosting Problem\`
- Ticket erstellt von: <@${interaction.user.id}> *(${interaction.user.tag})*
- Datum und Uhrzeit: \`${formatDateInBerlinTimezone(new Date())}\``)
    .setColor('#5865f2');


  const sentLogEmbed2 = await logChannel.send({ embeds: [logEmbed2] });

  const newTicket = {
    ticketId: channel.id,
    userid: interaction.user.id,
    usertag: interaction.user.tag,
    ticketpanel: "Hosting Problem",
    logEmbed2Id: sentLogEmbed2.id,
    claimed: false
  };

  tickets.tickets.push(newTicket);
  fs.writeFileSync(ticketPath, JSON.stringify(tickets, null, 2));

    await interaction.reply({ content: `\`✅\`〢Dein **Ticket** wurde hier **erstellt**: <#${channel.id}>`, ephemeral: true });
  
} catch (error) {
    await interaction.reply({ content: '`❌`〢Es ist ein **Fehler** aufgetreten! Bitte melde **folgendes** einem Administrator:``` ' + error + "```", ephemeral: true });
  
}
  }

 if (modalId === "partnerModal") {
      partnerinvite = interaction.fields.getTextInputValue('partnerinvite');
    serverbeschreibung = interaction.fields.getTextInputValue('serverbeschreibung') || '/';
   
    
try {
  const channel = await interaction.guild.channels.create({
    name: `🤝〢${interaction.user.username}`,
    type: ChannelType.GuildText,
    parent: '1299865222487474207',
    permissionOverwrites: [
      {
        id: interaction.guild.id,
        deny: [PermissionsBitField.Flags.ViewChannel],
      },
      {
        id: interaction.user.id,
        allow: [PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ViewChannel],
      },
      {
        id: '1298918662199312385',
        allow: [PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ViewChannel],
      },
    ],
  });

  const ticketEmbed = new EmbedBuilder()
    .setThumbnail(interaction.user.displayAvatarURL())
    .setDescription(`### <:Ticket:1303373350730596452> × WILLKOMMEN IM TICKET
› Bitte habe einen **kleinen Moment** gedult. Dir wird **so schnell wie möglich** ein Teammitglied **helfen**.
  
### <:Datei:1303373300554272789> - ANGEGEBENE DETAILS

› **Invite Link zu deinem Server**
\`${partnerinvite}\`

› **Kurze Beschreibung deines Server**
\`${serverbeschreibung}\`
`)
    .setColor('#5865f2');

    const closeButton = new ButtonBuilder()
    .setCustomId('close')
    .setLabel(' - Ticket schließen')
    .setEmoji('1303388353965592626')
    .setStyle(ButtonStyle.Secondary);

    const claimButton = new ButtonBuilder()
    .setCustomId('claim')
    .setLabel(' - Ticket beanspruchen')
    .setEmoji('1303388351822434335')
    .setStyle(ButtonStyle.Secondary);

  const embedRow = new ActionRowBuilder()
    .addComponents(closeButton, claimButton);

  await channel.send({ embeds: [ticketEmbed], components: [embedRow] });

  const logEmbed2 = new EmbedBuilder()
    .setDescription(`### <:Ticket:1303373350730596452> × TICKET WURDE GEÖFFNET
- Ticket-ID: \`#${interaction.channel.id}\`
- Ticket Panel: \`Partnerschaft\`
- Ticket erstellt von: <@${interaction.user.id}> *(${interaction.user.tag})*
- Datum und Uhrzeit: \`${formatDateInBerlinTimezone(new Date())}\``)
    .setColor('#5865f2');


  const sentLogEmbed2 = await logChannel.send({ embeds: [logEmbed2] });

  const newTicket = {
    ticketId: channel.id,
    userid: interaction.user.id,
    usertag: interaction.user.tag,
    ticketpanel: "Partnerschaft",
    logEmbed2Id: sentLogEmbed2.id,
    claimed: false
  };

  tickets.tickets.push(newTicket);
  fs.writeFileSync(ticketPath, JSON.stringify(tickets, null, 2));

    await interaction.reply({ content: `\`✅\`〢Dein **Ticket** wurde hier **erstellt**: <#${channel.id}>`, ephemeral: true });
  
} catch (error) {
    await interaction.reply({ content: '`❌`〢Es ist ein **Fehler** aufgetreten! Bitte melde **folgendes** einem Administrator:``` ' + error + "```", ephemeral: true });
  
}
 }
async function fetchAllPanelUsers() {
    let allUsers = [];
    let page = 1;
    let totalPages = 1;

    do {
        const response = await axios.get(`https://panel.einfxchpingu.net/api/application/users?page=${page}`, {
            headers: {
                'Authorization': 'Bearer peli_suIPnQBXdEleLxEZAamT272y6MCRmBoVrRxQ4l6yOdr',
                'Accept': 'application/json'
            }
        });

        const data = response.data;
        allUsers = allUsers.concat(data.data);
        totalPages = data.meta.pagination.total_pages;
        page++;
    } while (page <= totalPages);

    return allUsers;
}

if (modalId === 'hostingModal') {
    try {
        const panelUsers = await fetchAllPanelUsers();

        if (hosting.users) {
            hosting.users = hosting.users.filter(entry => 
                panelUsers.some(panelUser => 
                    panelUser.attributes.username === entry.benutzername &&
                    panelUser.attributes.email === entry.email
                )
            );
            fs.writeFileSync(hostingPath, JSON.stringify(hosting, null, 2));
        } else {
            hosting.users = [];
        }

        const hostingSprache = interaction.fields.getTextInputValue('hostingSprache');
        const hostingGrund = interaction.fields.getTextInputValue('hostingGrund');
        const hostingEmail = interaction.fields.getTextInputValue('hostingEmail');

        const isUserAlreadyRegistered = hosting.users.some(entry => entry.userid === interaction.user.id);
        const isUsernameTaken = panelUsers.some(panelUser => panelUser.attributes.username === hostingGrund);
        const isEmailTaken = panelUsers.some(panelUser => panelUser.attributes.email === hostingEmail);

        if (isUserAlreadyRegistered) {
            await interaction.reply({ 
                content: '`❌`〢Du hast **bereits** einen **Hosting-Account**! Bitte nutze deinen **bestehenden Zugang**.', 
                ephemeral: true 
            });
            return;
        }

        if (isUsernameTaken) {
            await interaction.reply({ 
                content: '`❌`〢Dieser **Benutzername** ist bereits vergeben. Bitte **wähle** einen **anderen**.', 
                ephemeral: true 
            });
            return;
        }

        if (isEmailTaken) {
            await interaction.reply({ 
                content: '`❌`〢Diese **E-Mail-Adresse** wird bereits verwendet. **Bitte** nutze eine **andere**.', 
                ephemeral: true 
            });
            return;
        }

        const password = crypto.randomBytes(6).toString('hex');
        const options = {
            method: 'POST',
            url: 'https://panel.einfxchpingu.net/api/application/users',
            headers: {'Content-Type': 'application/json', Accept: 'application/json', 'Authorization': 'Bearer peli_suIPnQBXdEleLxEZAamT272y6MCRmBoVrRxQ4l6yOdr'},
            data: {
                email: hostingEmail,
                username: hostingGrund,
                password: password,
                language: 'de',
                first_name: null,
                last_name: null
            }
        };

        const { data } = await axios.request(options);
        
        const netHosting = {
            userid: interaction.user.id,
            usertag: interaction.user.tag,
            runtime: hostingSprache,
            benutzername: hostingGrund,
            email: hostingEmail,
            messageId: interaction.message.id
        };

        hosting.users.push(netHosting);
        fs.writeFileSync(hostingPath, JSON.stringify(hosting, null, 2));

        const embed = new EmbedBuilder()
            .setColor(0x5865f2)
            .setDescription(`### <:blurple_members:1303729183306027070> × DEIN ACCOUNT WURDE ERSTELLT\n- **Benutzername**: \`${hostingGrund}\`\n- **E-mail**: \`${hostingEmail}\`\n- **Password** (Random): ||\`${password}\`|| *(Bitte ändern!)*
            
> https://panel.einfxchpingu.net
> *Die Erstellung deines Servers hat begonnen! Sollte er innerhalb von 30 Minuten nicht auftauchen, melde dich bitte in einem <#1298951101223145472>*`);

        await interaction.reply({ embeds: [embed], ephemeral: true});
        
        const logEmbed = new EmbedBuilder()
            .setDescription(`### <:Server:1303373305973313658> × NEUE SERVER BEANTRAGUNG!
<@${interaction.user.id}> *(${interaction.user.username})*
- **Benutzername**: \`${hostingGrund}\`
- **E-mail**: \`${hostingEmail}\`
- **Runtime**: \`${hostingSprache}\`

*Klicke unten auf den Button, wenn die Server Erstellung erfolgreich war. Der Benutzer wird benachrichtigt, dass sein Server erstellt wurde*`)
            .setColor('#5865f2');
        
        const abgeschlossenButton = new ButtonBuilder()
            .setCustomId('abgeschlossen')
            .setLabel(' - Erstellung abgeschlossen')
            .setEmoji('1299810000365031552')
            .setStyle(ButtonStyle.Secondary);

        const embedRow = new ActionRowBuilder().addComponents(abgeschlossenButton);
        const channel = await client.channels.fetch("1298922167244816394");
        await channel.send({ content: "<@&1298918662199312385>", embeds: [logEmbed], components: [embedRow] });

    } catch (error) {
        console.error('Fehler im Hosting-Modal:', error);
        await interaction.reply({ 
            content: '`❌`〢Ein Fehler ist aufgetreten. Bitte versuche es später erneut.', 
            ephemeral: true 
        });
    }
}

});

//partnerModal
client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return;
  
  const logChannel = await interaction.guild.channels.cache.get("1298922351320236032");
   const hostingSprache = new TextInputBuilder()
            .setCustomId('hostingSprache')
            .setLabel("💬 - Welche Programmiersprache?")
            .setStyle(TextInputStyle.Short)
            .setPlaceholder("Java, Javascript, Python")
            .setRequired(true);

        const hostingGrund = new TextInputBuilder()
            .setCustomId('hostingGrund')
            .setLabel("👤 - Benutzername")
            .setStyle(TextInputStyle.Short)
            .setPlaceholder("Wie sollst du heißen?")
            .setRequired(true);
          
 const hostingEmail = new TextInputBuilder()
            .setCustomId('hostingEmail')
            .setLabel("📫 - Email Adresse")
            .setStyle(TextInputStyle.Short)
            .setPlaceholder("Deine Email Adresse")
            .setRequired(true);


const hostingModal = new ModalBuilder()
  .setCustomId('hostingModal')
  .setTitle('🚀 - Server Hosting')
  .addComponents(
      new ActionRowBuilder().addComponents(hostingSprache),
            new ActionRowBuilder().addComponents(hostingGrund),
            new ActionRowBuilder().addComponents(hostingEmail)
  );
    
     const partnerinvite = new TextInputBuilder()
            .setCustomId('partnerinvite')
            .setLabel("🔗 - Invite Link zu deinem Server")
            .setStyle(TextInputStyle.Short)
            .setPlaceholder("discord.gg/..")
            .setRequired(true);

        const serverbeschreibung = new TextInputBuilder()
            .setCustomId('serverbeschreibung')
            .setLabel("👤 - Kurze Beschreibung deines Server")
            .setStyle(TextInputStyle.Paragraph)
            .setPlaceholder("Das Thema meines Servers ist..")
            .setRequired(true);


const partnerModal = new ModalBuilder()
  .setCustomId('partnerModal')
  .setTitle('🤝 - Partnerschaft')
  .addComponents(
      new ActionRowBuilder().addComponents(partnerinvite),
            new ActionRowBuilder().addComponents(serverbeschreibung)
  );
  try {
    const giveawayId = interaction.customId.split('_')[1];
    const serveruserId = interaction.customId.split('_')[1];
    if (interaction.customId === "abgeschlossen") {
        const serverIdd = hosting.users.find(u => u.messageId === interaction.message.id);
        const dmEmbed = new EmbedBuilder()
        .setDescription(`### <:Server:1303373305973313658> × DEIN SERVER WURDE ERSTELLT
› Dein Server wurde von <@${interaction.user.id}> erfolgreich erstellt und ist jetzt für dich sichtbar!

> https://panel.einfxchpingu.net`)
        .setColor('#5865f2');

     await interaction.reply({ content: `\`✅\`〢Der **Benutzer** wurde erfolgreich **benachrichtigt**!`, ephemeral: true });
        
      try {
      const user = await interaction.client.users.fetch(serverIdd.userid)
      await user.send({ embeds: [dmEmbed]});
} catch (error) {
    }
        interaction.message.delete();
    }
    if (interaction.customId === "inviteButton") {
        try {
  const channel = await interaction.guild.channels.create({
    name: `🔗〢${interaction.user.username}`,
    type: ChannelType.GuildText,
    parent: '1299865222487474207',
    permissionOverwrites: [
      {
        id: interaction.guild.id,
        deny: [PermissionsBitField.Flags.ViewChannel],
      },
      {
        id: interaction.user.id,
        allow: [PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ViewChannel],
      },
      {
        id: '1298918662199312385',
        allow: [PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ViewChannel],
      },
    ],
  });

  const ticketEmbed = new EmbedBuilder()
    .setThumbnail(interaction.user.displayAvatarURL())
    .setDescription(`### <:Ticket:1303373350730596452> × WILLKOMMEN IM TICKET
› Bitte habe einen **kleinen Moment** gedult. Dir wird **so schnell wie möglich** ein Teammitglied **helfen**.
  
### <:Datei:1303373300554272789> - ANGEGEBENE DETAILS
*Keine Details*`)
    .setColor('#5865f2');

    const closeButton = new ButtonBuilder()
    .setCustomId('close')
    .setLabel(' - Ticket schließen')
    .setEmoji('1303388353965592626')
    .setStyle(ButtonStyle.Secondary);

    const claimButton = new ButtonBuilder()
    .setCustomId('claim')
    .setLabel(' - Ticket beanspruchen')
    .setEmoji('1303388351822434335')
    .setStyle(ButtonStyle.Secondary);

  const embedRow = new ActionRowBuilder()
    .addComponents(closeButton, claimButton);

  await channel.send({ embeds: [ticketEmbed], components: [embedRow] });

  const logEmbed2 = new EmbedBuilder()
    .setDescription(`### <:Ticket:1303373350730596452> × TICKET WURDE GEÖFFNET
- Ticket-ID: \`#${interaction.channel.id}\`
- Ticket Panel: \`Invite Belohnung einfordern\`
- Ticket erstellt von: <@${interaction.user.id}> *(${interaction.user.tag})*
- Datum und Uhrzeit: \`${formatDateInBerlinTimezone(new Date())}\``)
    .setColor('#5865f2');


  const sentLogEmbed2 = await logChannel.send({ embeds: [logEmbed2] });

  const newTicket = {
    ticketId: channel.id,
    userid: interaction.user.id,
    usertag: interaction.user.tag,
    ticketpanel: "Invite Belohnung einfordern",
    logEmbed2Id: sentLogEmbed2.id,
    claimed: false
  };

  tickets.tickets.push(newTicket);
  fs.writeFileSync(ticketPath, JSON.stringify(tickets, null, 2));

    await interaction.reply({ content: `\`✅\`〢Dein **Ticket** wurde hier **erstellt**: <#${channel.id}>`, ephemeral: true });
  
} catch (error) {
    await interaction.reply({ content: '`❌`〢Es ist ein **Fehler** aufgetreten! Bitte melde **folgendes** einem Administrator:``` ' + error + "```", ephemeral: true });
  
}
    }
    if (interaction.customId === 'claim') {
        
        const teamRole = interaction.guild.roles.cache.get('1298918662199312385');

if (!interaction.member.roles.cache.has(teamRole.id)) {
    return interaction.reply({ 
        content: `\`❌\`〢Nur **Teammitglieder** können **Tickets** beanspruchen!`, 
        ephemeral: true 
    });
}
 
      const ticketData = tickets.tickets.find(t => t.ticketId === interaction.channel.id);
       if (ticketData.claimed) {
      return interaction.reply({ content: '`❌`〢Dieses **Ticket** wurde bereits **beansprucht**.', ephemeral: true });
    }
    const claimEmbed = new EmbedBuilder()
      .setDescription(`### <:4020_blurple_wave:1303716667704082462> × Dein Ticket wurde beansprucht!
› <@${interaction.user.id}> ist nun **hier** und wird dir bei deinem **Anliegen** helfen.`)
      .setColor('#5865f2');

    ticketData.claimed = true;
      

    await interaction.reply({ embeds: [claimEmbed] });
    fs.writeFileSync(ticketPath, JSON.stringify(tickets, null, 2));
  }
        if (interaction.customId === 'hosting') {
          await interaction.showModal(hostingModal);
        } else if (interaction.customId === 'partnerschaft') {
          await interaction.showModal(partnerModal);
        } else if (interaction.customId === 'verweigerung') {
          const channelid = interaction.channelId;
          const channel = await client.channels.fetch(channelid);
        
          const ticketData = tickets.tickets.find(t => t.ticketId === interaction.channel.id);
        
          if (interaction.user.id !== ticketData.userid) {
        return interaction.reply({ content:"`❌`〢Du kannst das nicht tun!", ephemeral: true });
    }
      interaction.message.delete();
        } else if (interaction.customId === 'close' || interaction.customId === 'accept') {
          const channelid = interaction.channelId;
          const channel = await client.channels.fetch(channelid);
        
          const ticketData = tickets.tickets.find(t => t.ticketId === interaction.channel.id);        
      if (interaction.customId === 'accept' && interaction.user.id !== ticketData.userid) {
        return await interaction.reply({ content: "`❌`〢Du kannst das nicht tun!", ephemeral: true });
      }
      
      const logEmbed = new EmbedBuilder()
        .setDescription(`### <:Ticket:1303373350730596452> × TICKET WURDE GESCHLOSSEN
- Ticket-ID: \`#${interaction.channel.id}\`
- Ticket Panel: \`${ticketData.ticketpanel}\`
- Ticket erstellt von: <@${ticketData.userid}> *(${ticketData.usertag})*
- Ticket geschlossen von: <@${interaction.user.id}> *(${interaction.user.tag})*
- Datum & Uhrzeit: \`${formatDateInBerlinTimezone(new Date())}\``)
        .setColor('#5865f2');

  
      await logChannel.send({ embeds: [logEmbed] });

      const dmEmbed = new EmbedBuilder()
        .setDescription(`### <:Ticket:1303373350730596452> × TICKET WURDE GESCHLOSSEN
› Dein Ticket auf *${interaction.guild.name}* wurde von <@${interaction.user.id}> geschlossen.

### <:Datei:1303373300554272789> - TICKET DETAILS
- Ticket-Panel: \`${ticketData.ticketpanel}\`
- Datum und Uhrzeit: \`${formatDateInBerlinTimezone(new Date())}\``)
        .setColor('#5865f2');

      const ratingMenu = new StringSelectMenuBuilder()
        .setCustomId('ticket_rating')
        .setPlaceholder('📋 × Bewerte den Support')
        .addOptions(
          new StringSelectMenuOptionBuilder()
            .setLabel('5 × ⭐⭐⭐⭐⭐')
            .setValue('star_five'),
          new StringSelectMenuOptionBuilder()
            .setLabel('4 × ⭐⭐⭐⭐')
            .setValue('star_four'),
          new StringSelectMenuOptionBuilder()
            .setLabel('3 × ⭐⭐⭐')
            .setValue('star_three'),
          new StringSelectMenuOptionBuilder()
            .setLabel('2 × ⭐⭐')
            .setValue('star_two'),
          new StringSelectMenuOptionBuilder()
            .setLabel('1 × ⭐')
            .setValue('star_one'),
        );

      const ratingRow = new ActionRowBuilder()
        .addComponents(ratingMenu);

      const user = await interaction.client.users.fetch(ticketData.userid)
      try {
      await user.send({ embeds: [dmEmbed], components: [ratingRow] });
} catch (error) {
    }
      await interaction.reply({ content: "`🔒`〢Das **Ticket** wurde erfolgreich **geschlossen!**" });
      
      const dataIndex = tickets.tickets.indexOf(ticketData);
      if (dataIndex > -1) {
        tickets.tickets.splice(dataIndex, 1);
        fs.writeFileSync(ticketPath, JSON.stringify(tickets, null, 2));
      }

      await channel.delete();
    } else if (interaction.customId.startsWith('join_')) {
  const giveawayId = interaction.customId.split('_')[1];
  const giveaway = gw.giveaways.find(g => g.messageId === interaction.message.id);

  if (!giveaway) {
    return interaction.reply({ content: '`❌`〢Dieses **Gewinnspiel** existiert nicht', ephemeral: true });
  }

  await interaction.deferUpdate();

  let messageContent;
  if (giveaway.participants.includes(interaction.user.id)) {
    giveaway.participants = giveaway.participants.filter(p => p !== interaction.user.id);
    messageContent = '`🚪`〢Du **hast** das Gewinnspiel **verlassen**!';
  } else {
    giveaway.participants.push(interaction.user.id);
    messageContent = '`🎉`〢Du **nimmst** jetzt an dem **Gewinnspiel** teil!';
  }

  const embed = new EmbedBuilder()
    .setDescription(`### <:Geschenk:1303373310528192534> × NEUES GEWINNSPIEL
› Preis: **${giveaway.prize}**

### <:Datei:1303373300554272789> - DETAILS
- Teilnehmer: **${giveaway.participants.length}**
- Gewinner: **${giveaway.winners}**
- Endet: <t:${Math.floor(giveaway.endTime / 1000)}:R> (<t:${Math.floor(giveaway.endTime / 1000)}:f>)
- Erstellt von: <@${giveaway.creator}>

› Klicke unten auf die Schaltfläche, um am Gewinnspiel teilzunehmen. Ein weiterer Klick, um deine Teilnahme zurückzuziehen.`)
    .setColor('#5865f2');

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`join_${giveawayId}`)
      .setLabel(' - Teilnehmen')
      .setEmoji('1303373310528192534')
      .setStyle(ButtonStyle.Secondary)
  );

  await interaction.editReply({ embeds: [embed], components: [row] });
  await interaction.followUp({ content: messageContent, ephemeral: true });

  fs.writeFileSync(gwPath, JSON.stringify(gw, null, 2));
}

  } catch (error) {
    console.log(error);
  }
});

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isStringSelectMenu()) return;
  if (interaction.customId !== 'ticket_rating') return;

  const guild = client.guilds.cache.get('1298766626597896386');

  const logChannel = guild.channels.cache.get("1298922351320236032");
  const selectedValue = interaction.values[0];
  const ratingDescriptions = {
    'star_five': '5 × ⭐⭐⭐⭐⭐',
    'star_four': '4 × ⭐⭐⭐⭐',
    'star_three': '3 × ⭐⭐⭐',
    'star_two': '2 × ⭐⭐',
    'star_one': '1 × ⭐',
  };

  const ratingDescription = ratingDescriptions[selectedValue] || 'Keine Bewertung verfügbar';

  try {
    const oldEmbed = interaction.message.embeds[0];
    let oldDescription = oldEmbed ? oldEmbed.description || '' : '';

    const descriptionLines = oldDescription.split('\n');
    const lastTwoLines = descriptionLines.slice(-2).join('\n');
    const modifiedDescription = lastTwoLines.replace(/>/g, '・');

    await interaction.message.edit({
      embeds: [new EmbedBuilder()
        .setDescription(`### <:Stern:1303373346398015530> × DANKE FÜR DEIN FEEDBACK
          › Vielen Dank! *(${ratingDescription})*`)
        .setColor('#5865f2')],
      components: []
    });

    if (logChannel) {
      const ratingEmbed = new EmbedBuilder()
        .setDescription(`### <:Sterne:1303373321244639242> × TICKET BEWERTUNG
- Bewertung: *${ratingDescription}*
- Bewertet von: <@${interaction.user.id}> *(${interaction.user.tag})*
${modifiedDescription}`)
        .setColor('#5865f2');

      await logChannel.send({ embeds: [ratingEmbed] });
    }

    await interaction.reply({ content: '`✅`〢Danke für dein **Feedback**!', ephemeral: true });
  } catch (error) {
    await interaction.reply({ content: '`❌`〢Es ist ein **Fehler** aufgetreten!', ephemeral: true });
  }
});

client.login(token);
